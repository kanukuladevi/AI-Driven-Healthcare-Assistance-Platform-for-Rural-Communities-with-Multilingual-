import React, { useState, useEffect } from 'react';
import {
  HeartHandshake,
  User,
  Camera,
  Mic,
  Clock,
  ShieldAlert,
  FileText,
  Volume2,
  Calendar,
  Building2,
  CheckCircle2,
  MapPin,
  Phone,
  Sparkles,
  ArrowRight,
  ChevronRight,
  AlertTriangle,
} from 'lucide-react';
import { SupportedLanguage, Patient, PrescriptionRecord, MedicationReminder, AppData } from './types';
import { TRANSLATIONS } from './translations';
import { Header } from './components/Header';
import { PatientProfileModal } from './components/PatientProfileModal';
import { PrescriptionUploadSection } from './components/PrescriptionUploadSection';
import { PrescriptionDetailCard } from './components/PrescriptionDetailCard';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { MedicationRemindersView } from './components/MedicationRemindersView';
import { HealthEducationEmergencyView } from './components/HealthEducationEmergencyView';
import { AshaWorkerView } from './components/AshaWorkerView';
import { AdminDashboardView } from './components/AdminDashboardView';
import { speechManager } from './utils/audio';

export default function App() {
  const [appData, setAppData] = useState<AppData | null>(null);
  const [currentLanguage, setCurrentLanguage] = useState<SupportedLanguage>('te');
  const [activeRole, setActiveRole] = useState<'patient' | 'asha' | 'admin'>('patient');
  const [activePatient, setActivePatient] = useState<Patient | null>(null);
  const [activeTab, setActiveTab] = useState<'home' | 'upload' | 'reminders' | 'education'>('home');

  // Modals
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isAudioSpeaking, setIsAudioSpeaking] = useState(false);

  const t = TRANSLATIONS[currentLanguage];

  // Fetch initial data
  const fetchData = async () => {
    try {
      const res = await fetch('/api/data');
      const data: AppData = await res.json();
      setAppData(data);
      if (!activePatient && data.patients.length > 0) {
        setActivePatient(data.patients[0]);
        setCurrentLanguage(data.patients[0].preferredLanguage || 'te');
      }
    } catch (err) {
      console.error('Failed to load app data:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Sync audio speaking state
  useEffect(() => {
    const interval = setInterval(() => {
      setIsAudioSpeaking(speechManager.getIsSpeaking());
    }, 400);
    return () => clearInterval(interval);
  }, []);

  const handlePatientSelect = (pat: Patient) => {
    setActivePatient(pat);
    setCurrentLanguage(pat.preferredLanguage);
    setIsProfileModalOpen(false);
  };

  const handleRegisterPatient = async (newPatData: any) => {
    const res = await fetch('/api/patients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPatData),
    });
    const result = await res.json();
    if (result.success && result.patient) {
      await fetchData();
      setActivePatient(result.patient);
      setCurrentLanguage(result.patient.preferredLanguage);
    }
  };

  const handlePrescriptionExtracted = (rx: PrescriptionRecord) => {
    fetchData();
    setActiveTab('home');
    speechManager.playChime(true);
  };

  const handleToggleReminder = async (reminderId: string) => {
    await fetch('/api/reminders/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reminderId }),
    });
    await fetchData();
  };

  const handleUpdateAshaNotes = async (
    prescriptionId: string,
    notes: string,
    verified: boolean
  ) => {
    await fetch('/api/asha/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prescriptionId, notes, verified }),
    });
    await fetchData();
  };

  const handleStopAudio = () => {
    speechManager.stop();
    setIsAudioSpeaking(false);
  };

  if (!appData) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto animate-bounce shadow-md">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <p className="text-sm font-bold text-stone-900">
            ఆరోగ్యసేతు గ్రామీణ వ్యవస్థ ప్రారంభమవుతోంది...
          </p>
          <p className="text-xs text-stone-500 font-mono">
            Loading rural healthcare network...
          </p>
        </div>
      </div>
    );
  }

  // Find prescriptions & reminders for active patient
  const patientPrescriptions = appData.prescriptions.filter(
    (p) => !activePatient || p.patientId === activePatient.id
  );
  const latestPrescription = patientPrescriptions[0] || appData.prescriptions[0];

  const patientReminders = appData.reminders.filter(
    (r) => !activePatient || r.patientId === activePatient.id
  );

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col pb-20 md:pb-10 font-sans selection:bg-emerald-200">
      {/* Top Bar Header Contract */}
      <Header
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
        activeRole={activeRole}
        onRoleChange={setActiveRole}
        activePatient={activePatient}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        isAudioSpeaking={isAudioSpeaking}
        onStopAudio={handleStopAudio}
        onOpenEmergency={() => setIsEmergencyModalOpen(true)}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-5 sm:py-6 w-full flex-1">
        {/* ROLE 1: PATIENT APPLICATION */}
        {activeRole === 'patient' && (
          <div className="space-y-6">
            {/* Step 1: Patient Header Banner & Health Identity Card */}
            {activePatient && (
              <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-stone-900 text-white rounded-3xl p-5 sm:p-6 shadow-sm relative overflow-hidden">
                <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold px-2 py-0.5 bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 rounded-md">
                        {t.patientProfileTitle}
                      </span>
                      <span className="text-xs text-emerald-300 font-mono">
                        {activePatient.healthId}
                      </span>
                    </div>

                    <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white font-indic">
                      {activePatient.name}
                    </h1>

                    <div className="flex flex-wrap items-center gap-2 text-xs text-emerald-100">
                      <span>{activePatient.age} yrs · {activePatient.gender}</span>
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-emerald-300" />
                        {activePatient.village}, {activePatient.district}
                      </span>
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5 text-emerald-300" />
                        {activePatient.mobile}
                      </span>
                    </div>
                  </div>

                  {/* Switch Patient & Open Voice Assistant CTAs */}
                  <div className="flex items-center gap-2.5 shrink-0">
                    <button
                      onClick={() => setIsVoiceModalOpen(true)}
                      className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-900 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-xs transition-transform active:scale-95"
                    >
                      <Mic className="w-4 h-4 text-stone-900" />
                      <span>{t.voiceTitle.split('(')[0].trim()}</span>
                    </button>

                    <button
                      onClick={() => setIsProfileModalOpen(true)}
                      className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl border border-white/20 transition-colors"
                    >
                      {t.switchPatient}
                    </button>
                  </div>
                </div>

                {/* Patient Health Condition Tags */}
                {activePatient.chronicConditions.length > 0 && (
                  <div className="relative z-10 mt-4 pt-3 border-t border-emerald-700/60 flex flex-wrap items-center gap-2 text-xs text-emerald-200">
                    <span className="text-emerald-300 font-semibold">
                      నమోదైన సమస్యలు (Health Records):
                    </span>
                    {activePatient.chronicConditions.map((c, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 bg-emerald-950/60 text-emerald-100 rounded-md border border-emerald-600/40 text-[11px]"
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Desktop Navigation Sub-Tabs */}
            <div className="flex items-center gap-2 border-b border-stone-200 pb-2 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setActiveTab('home')}
                className={`min-h-[44px] px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                  activeTab === 'home'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>{t.tabHome}</span>
              </button>

              <button
                onClick={() => setActiveTab('upload')}
                className={`min-h-[44px] px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                  activeTab === 'upload'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                <Camera className="w-4 h-4" />
                <span>{t.tabUpload}</span>
              </button>

              <button
                onClick={() => setActiveTab('reminders')}
                className={`min-h-[44px] px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                  activeTab === 'reminders'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>{t.tabReminders} ({patientReminders.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('education')}
                className={`min-h-[44px] px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                  activeTab === 'education'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                <ShieldAlert className="w-4 h-4" />
                <span>{t.tabHealthEdu}</span>
              </button>

              {/* Direct Voice Assistant Launcher Button */}
              <button
                onClick={() => setIsVoiceModalOpen(true)}
                className="min-h-[44px] px-4 py-2 text-xs sm:text-sm font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-xl transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ml-auto"
              >
                <Mic className="w-4 h-4 text-amber-800" />
                <span className="font-indic">{t.tabVoice}</span>
              </button>
            </div>

            {/* TAB CONTENT */}
            {activeTab === 'home' && (
              <div className="space-y-6">
                {/* Prescription Detail Section (Step 3: Translation & Simplification) */}
                {latestPrescription ? (
                  <div className="space-y-4">
                    <PrescriptionDetailCard
                      prescription={latestPrescription}
                      currentLanguage={currentLanguage}
                      onAddToReminders={() => fetchData()}
                    />
                  </div>
                ) : (
                  <div className="p-8 text-center bg-white rounded-2xl border border-stone-200">
                    <FileText className="w-12 h-12 text-stone-400 mx-auto mb-2" />
                    <h3 className="font-bold text-stone-800">
                      ప్రిస్క్రిప్షన్ ఏదీ లేదు (No Prescriptions Yet)
                    </h3>
                    <p className="text-xs text-stone-500 max-w-sm mx-auto mt-1 mb-4">
                      డాక్టర్ రాసిన కాగితాన్ని ఫోటో తీసి అప్‌లోడ్ చేయండి.
                    </p>
                    <button
                      onClick={() => setActiveTab('upload')}
                      className="px-4 py-2 bg-emerald-700 text-white text-xs font-bold rounded-xl"
                    >
                      {t.uploadTitle}
                    </button>
                  </div>
                )}

                {/* Quick Reminders Preview on Home */}
                <div className="pt-2">
                  <MedicationRemindersView
                    reminders={patientReminders}
                    onToggleReminder={handleToggleReminder}
                    currentLanguage={currentLanguage}
                  />
                </div>
              </div>
            )}

            {activeTab === 'upload' && (
              <div className="space-y-6">
                {/* Step 2: Upload prescription via Camera, file, or Sample */}
                <PrescriptionUploadSection
                  currentLanguage={currentLanguage}
                  activePatient={activePatient}
                  onPrescriptionExtracted={handlePrescriptionExtracted}
                />

                {/* History of prescriptions */}
                {patientPrescriptions.length > 0 && (
                  <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-3">
                    <h3 className="text-sm font-bold text-stone-900">
                      గతంలో నమోదైన ప్రిస్క్రిప్షన్లు (Previous Prescriptions - {patientPrescriptions.length})
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {patientPrescriptions.map((rx) => (
                        <div
                          key={rx.id}
                          className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 text-xs space-y-1.5"
                        >
                          <div className="flex justify-between font-bold text-stone-900">
                            <span>{rx.doctorName}</span>
                            <span className="font-mono text-stone-500">{rx.visitDate}</span>
                          </div>
                          <p className="text-stone-600 font-medium">
                            {rx.facilityName}
                          </p>
                          <p className="font-semibold text-emerald-900 font-indic">
                            {rx.diagnosis}
                          </p>
                          <span className="inline-block text-[11px] text-stone-500">
                            {rx.medications.length} Medicines Prescribed
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'reminders' && (
              <MedicationRemindersView
                reminders={patientReminders}
                onToggleReminder={handleToggleReminder}
                currentLanguage={currentLanguage}
              />
            )}

            {activeTab === 'education' && (
              <HealthEducationEmergencyView currentLanguage={currentLanguage} />
            )}
          </div>
        )}

        {/* ROLE 2: ASHA HEALTHCARE WORKER PORTAL */}
        {activeRole === 'asha' && (
          <AshaWorkerView
            patients={appData.patients}
            prescriptions={appData.prescriptions}
            reminders={appData.reminders}
            ashaWorkers={appData.ashaWorkers}
            currentLanguage={currentLanguage}
            onOpenPatientModal={() => setIsProfileModalOpen(true)}
            onSelectPatient={setActivePatient}
            onUpdateNotes={handleUpdateAshaNotes}
          />
        )}

        {/* ROLE 3: ADMIN & PHC COORDINATOR DASHBOARD */}
        {activeRole === 'admin' && (
          <AdminDashboardView
            appData={appData}
            currentLanguage={currentLanguage}
          />
        )}
      </main>

      {/* MOBILE FIXED BOTTOM TAB BAR (Complies with 10_mobile_touch_apps.md) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 py-1 px-2 flex items-center justify-around shadow-lg">
        <button
          onClick={() => {
            setActiveRole('patient');
            setActiveTab('home');
          }}
          className={`min-h-[48px] min-w-[48px] flex flex-col items-center justify-center p-1 rounded-xl transition-colors ${
            activeRole === 'patient' && activeTab === 'home'
              ? 'text-emerald-700 font-bold'
              : 'text-stone-500'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">హోమ్</span>
        </button>

        <button
          onClick={() => {
            setActiveRole('patient');
            setActiveTab('upload');
          }}
          className={`min-h-[48px] min-w-[48px] flex flex-col items-center justify-center p-1 rounded-xl transition-colors ${
            activeRole === 'patient' && activeTab === 'upload'
              ? 'text-emerald-700 font-bold'
              : 'text-stone-500'
          }`}
        >
          <Camera className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">చీటీ స్కాన్</span>
        </button>

        {/* Center Floating Mic Button */}
        <button
          onClick={() => setIsVoiceModalOpen(true)}
          className="min-h-[50px] min-w-[50px] -mt-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform border-4 border-white"
        >
          <Mic className="w-6 h-6" />
        </button>

        <button
          onClick={() => {
            setActiveRole('patient');
            setActiveTab('reminders');
          }}
          className={`min-h-[48px] min-w-[48px] flex flex-col items-center justify-center p-1 rounded-xl transition-colors ${
            activeRole === 'patient' && activeTab === 'reminders'
              ? 'text-emerald-700 font-bold'
              : 'text-stone-500'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">మందులు</span>
        </button>

        <button
          onClick={() => setIsEmergencyModalOpen(true)}
          className="min-h-[48px] min-w-[48px] flex flex-col items-center justify-center p-1 rounded-xl text-rose-600 font-bold"
        >
          <ShieldAlert className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">108 SOS</span>
        </button>
      </nav>

      {/* MODAL 1: Patient Registration & Profile Switcher */}
      <PatientProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        patients={appData.patients}
        activePatient={activePatient}
        onSelectPatient={handlePatientSelect}
        onRegisterPatient={handleRegisterPatient}
        currentLanguage={currentLanguage}
      />

      {/* MODAL 2: Voice Healthcare Assistant (Speech STT/TTS) */}
      <VoiceAssistantModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        currentLanguage={currentLanguage}
        activePatient={activePatient}
        activePrescription={latestPrescription}
        onOpenEmergency={() => {
          setIsVoiceModalOpen(false);
          setIsEmergencyModalOpen(true);
        }}
      />

      {/* MODAL 3: Emergency 108 SOS Direct Triage */}
      {isEmergencyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border-2 border-rose-400 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center">
                <ShieldAlert className="w-7 h-7" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-rose-950">
                  అత్యవసర సహాయం (108 SOS)
                </h3>
                <p className="text-xs text-rose-700">
                  Government Emergency Ambulance & Medical Aid
                </p>
              </div>
            </div>

            <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-xs text-rose-900 font-indic leading-relaxed">
              ఛాతీలో నొప్పి, తీవ్రమైన శ్వాస ఇబ్బంది, పక్షవాత లక్షణాలు లేదా స్పృహ తప్పడం ఉంటే ఏమాత్రం ఆలస్యం చేయకుండా వెంటనే 108 కు కాల్ చేయండి.
            </div>

            <div className="space-y-2">
              <a
                href="tel:108"
                className="w-full py-3.5 bg-rose-600 hover:bg-rose-700 text-white text-base font-bold rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
              >
                <Phone className="w-5 h-5" />
                <span>108 అంబులెన్స్ కాల్ చేయండి (ఉచితం)</span>
              </a>

              <a
                href="tel:104"
                className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>104 వైద్య సలహా హెల్ప్‌లైన్</span>
              </a>
            </div>

            <button
              onClick={() => setIsEmergencyModalOpen(false)}
              className="w-full py-2 text-xs font-semibold text-stone-500 hover:text-stone-800"
            >
              రద్దు చేయండి (Close)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
