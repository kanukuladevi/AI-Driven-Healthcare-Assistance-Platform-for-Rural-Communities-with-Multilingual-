import { SupportedLanguage } from './types';

export interface TranslationDictionary {
  appTitle: string;
  appSubtitle: string;
  rolePatient: string;
  roleAsha: string;
  roleAdmin: string;
  
  // Navigation / Tabs
  tabHome: string;
  tabUpload: string;
  tabVoice: string;
  tabReminders: string;
  tabHealthEdu: string;
  tabAshaNotes: string;

  // Step 1: Profile & Registration
  patientProfileTitle: string;
  healthIdBadge: string;
  villageName: string;
  phoneNumber: string;
  preferredLanguage: string;
  switchPatient: string;
  newPatientRegistration: string;
  saveProfile: string;

  // Step 2: Prescription Upload
  uploadTitle: string;
  uploadSubtitle: string;
  takePhoto: string;
  chooseFile: string;
  trySamplePrescription: string;
  processingPrescription: string;
  ocrExtracting: string;

  // Step 3: AI Translation & Plain Language
  translationTitle: string;
  doctorOriginal: string;
  patientSimplified: string;
  listenToAudio: string;
  stopAudio: string;
  audioPlaying: string;
  medicalTermsHeader: string;
  precautionsHeader: string;
  reviewDoctorDays: string;

  // Step 4: Voice Assistant
  voiceTitle: string;
  voiceSubtitle: string;
  tapToSpeak: string;
  listeningNow: string;
  askDoctorQuestion: string;
  sampleQuestions: string[];
  safetyDisclaimer: string;

  // Step 5: Reminders
  remindersTitle: string;
  remindersSubtitle: string;
  morningSlot: string;
  afternoonSlot: string;
  nightSlot: string;
  markAsTaken: string;
  doseTaken: string;
  adherenceScore: string;
  goodAdherenceMessage: string;

  // Step 6: Emergency & Health Education
  emergencyTitle: string;
  emergencySubtitle: string;
  call108: string;
  call104: string;
  phcDirectCall: string;
  redFlagsWarning: string;
  orsGuideTitle: string;
  feverGuideTitle: string;
  bpDiabetesGuideTitle: string;
}

export const TRANSLATIONS: Record<SupportedLanguage, TranslationDictionary> = {
  te: {
    appTitle: 'ఆరోగ్యసేతు గ్రామీణ',
    appSubtitle: 'గ్రామీణ రోగుల కోసం AI బహుభాషా ఆరోగ్య సహాయక వేదిక',
    rolePatient: 'రోగి అప్లికేషన్',
    roleAsha: 'ఆశా కార్యకర్త పోర్టల్',
    roleAdmin: 'PHC అడ్మిన్ డ్యాష్‌బోర్డ్',

    tabHome: 'హోమ్ & సమాచారం',
    tabUpload: 'ప్రిస్క్రిప్షన్ అప్‌లోడ్',
    tabVoice: 'వాయిస్ సహాయకుడు',
    tabReminders: 'మందుల రిమైండర్లు',
    tabHealthEdu: 'ఆరోగ్య విద్య & ఎమర్జెన్సీ',
    tabAshaNotes: 'ఆశా ఫాలో-అప్',

    patientProfileTitle: 'రోగి ఆరోగ్య గుర్తింపు కార్డు',
    healthIdBadge: 'ABHA ఐడీ',
    villageName: 'గ్రామం',
    phoneNumber: 'ఫోన్ నంబర్',
    preferredLanguage: 'ప్రాధాన్య భాష',
    switchPatient: 'రోగిని మార్చండి',
    newPatientRegistration: 'కొత్త రోగి నమోదు',
    saveProfile: 'ప్రొఫైల్ సేవ్ చేయండి',

    uploadTitle: 'డాక్టర్ ప్రిస్క్రిప్షన్ ఫోటో తీయండి / అప్‌లోడ్ చేయండి',
    uploadSubtitle: 'ఇంగ్లీష్ లేదా చేతిరాతలో ఉన్న చీటీని మీ స్వభాషలోకి తేలికగా అనువదించి అర్థమయ్యేలా వివరిస్తుంది.',
    takePhoto: 'కెమెరాతో ఫోటో తీయండి',
    chooseFile: 'ఫైల్ / PDF ఎంచుకోండి',
    trySamplePrescription: 'తెలంగాణ PHC నమూనా ప్రిస్క్రిప్షన్‌తో పరిశీలించండి',
    processingPrescription: 'AI ప్రిస్క్రిప్షన్ చదువుతోంది & అనువదిస్తోంది...',
    ocrExtracting: 'మందులు, మోతాదు, సమయాలు వెలికితీస్తోంది...',

    translationTitle: 'తెలుగులో తేలికపాటి వివరణ & మోతాదు',
    doctorOriginal: 'డాక్టర్ అసలు సూచనలు (ఇంగ్లీష్)',
    patientSimplified: 'మీకు అర్థమయ్యే తేలికపాటి వివరణ',
    listenToAudio: 'స్పష్టంగా వినండి (వాయిస్)',
    stopAudio: 'ఆడియో ఆపండి',
    audioPlaying: 'వాయిస్ ప్లే అవుతోంది...',
    medicalTermsHeader: 'వైద్య పదాల అర్థాలు (సులభ శైలి)',
    precautionsHeader: 'ముఖ్యమైన జాగ్రత్తలు',
    reviewDoctorDays: 'డాక్టర్‌ను మళ్ళీ కలవవలసిన సమయం',

    voiceTitle: 'వాయిస్ హెల్త్‌కేర్ అసిస్టెంట్ (మాట్లాడి అడగండి)',
    voiceSubtitle: 'చదవడం కష్టంగా ఉందా? మైక్రోఫోన్ నొక్కి మీ ప్రశ్నను తెలుగులో అడగండి. సమాధానం వినిపిస్తుంది.',
    tapToSpeak: 'మాట్లాడటానికి మైక్ నొక్కండి',
    listeningNow: 'వినబడుతోంది... మాట్లాడండి',
    askDoctorQuestion: 'ఈ మందు గురించి అడగండి...',
    sampleQuestions: [
      'ఈ మందు ఎందుకు వాడాలి?',
      'భోజనం చేసిన తర్వాత వేసుకోవాలా?',
      'ఒకవేళ మందు వేసుకోవడం మర్చిపోతే ఏం చేయాలి?',
      'నాకు ఛాతీలో తీవ్రమైన నొప్పి ఉంది',
    ],
    safetyDisclaimer: 'గమనిక: ఇది సహాయక వేదిక మాత్రమే. అత్యవసర పరిస్థితుల్లో వెంటనే 108 కు కాల్ చేయండి లేదా సమీప PHC డాక్టర్‌ను సంప్రదించండి.',

    remindersTitle: 'నేటి మందుల షెడ్యూల్ & రిమైండర్లు',
    remindersSubtitle: 'డాక్టర్ సూచించిన సమయానికి మందులు వేసుకుని "వేసుకున్నాను" అని నొక్కండి.',
    morningSlot: 'ఉదయం (టిఫిన్ తర్వాత)',
    afternoonSlot: 'మధ్యాహ్నం (భోజనం తర్వాత)',
    nightSlot: 'రాత్రి (భోజనం తర్వాత)',
    markAsTaken: 'మందు వేసుకున్నాను ✓',
    doseTaken: 'సకాలంలో వేసుకున్నారు',
    adherenceScore: 'మందుల క్రమశిక్షణ స్కోరు',
    goodAdherenceMessage: 'చాలా మంచిది! మీరు మందులు సకాలంలో వాడుతున్నారు.',

    emergencyTitle: 'అత్యవసర సహాయం & గ్రామ ఆరోగ్య సంరక్షణ',
    emergencySubtitle: 'ఆలస్యం చేయకుండా వెంటనే ఉచిత వైద్య సహాయం పొందండి.',
    call108: '108 అంబులెన్స్ (ఉచితం)',
    call104: '104 ఆరోగ్య సలహా హెల్ప్‌లైన్',
    phcDirectCall: 'సమీప నర్సంపేట PHC కాల్',
    redFlagsWarning: 'ఎరుపు రంగు అత్యవసర సంకేతాలు: గుండె నొప్పి, ఊపిరాడకపోవడం, స్పృహ కోల్పోవడం - వెంటనే 108 ను పిలవండి!',
    orsGuideTitle: 'ఇంట్లోనే ORS ద్రావణం తయారీ విధానం',
    feverGuideTitle: 'వర్షాకాల జ్వరాలు & దోమల నివారణ',
    bpDiabetesGuideTitle: 'రక్తపోటు (బీపీ) & షుగర్ నివారణ మార్గాలు',
  },
  hi: {
    appTitle: 'आरोग्यसेतु ग्रामीण',
    appSubtitle: 'ग्रामीण मरीजों के लिए AI बहुभाषी स्वास्थ्य सहायता मंच',
    rolePatient: 'मरीज एप्लिकेशन',
    roleAsha: 'आशा कार्यकर्ता पोर्टल',
    roleAdmin: 'PHC एडमिन डैशबोर्ड',

    tabHome: 'होम व जानकारी',
    tabUpload: 'पर्चा अपलोड करें',
    tabVoice: 'आवाज़ सहायक (Voice)',
    tabReminders: 'दवा रिमाइंडर',
    tabHealthEdu: 'स्वास्थ्य शिक्षा व आपातकाल',
    tabAshaNotes: 'आशा फॉलो-अप',

    patientProfileTitle: 'मरीज स्वास्थ्य पहचान पत्र',
    healthIdBadge: 'ABHA आईडी',
    villageName: 'गाँव',
    phoneNumber: 'मोबाइल नंबर',
    preferredLanguage: 'पसंदीदा भाषा',
    switchPatient: 'मरीज बदलें',
    newPatientRegistration: 'नया मरीज पंजीकरण',
    saveProfile: 'प्रोफाइल सहेजें',

    uploadTitle: 'डॉक्टर का पर्चा (Prescription) अपलोड या फोटो लें',
    uploadSubtitle: 'अंग्रेजी में लिखे पर्चे को अपनी सरल भाषा में समझें और दवाइयों का सही समय जानें।',
    takePhoto: 'कैमरे से फोटो लें',
    chooseFile: 'गैलरी / PDF चुनें',
    trySamplePrescription: 'सरकारी PHC नमूना पर्चा लोड करें',
    processingPrescription: 'AI पर्चा पढ़ रहा है और अनुवाद कर रहा है...',
    ocrExtracting: 'दवा, खुराक, और खाने का समय निकाल रहे हैं...',

    translationTitle: 'सरल भाषा में दवा की खुराक व समय',
    doctorOriginal: 'डॉक्टर का मूल निर्देश (अंग्रेजी)',
    patientSimplified: 'मरीज के लिए आसान व्याख्या',
    listenToAudio: 'आवाज़ में सुनें (Audio)',
    stopAudio: 'आवाज़ रोकें',
    audioPlaying: 'आवाज़ बज रही है...',
    medicalTermsHeader: 'चिकित्सा शब्दों का आसान अर्थ',
    precautionsHeader: 'जरूरी सावधानियां',
    reviewDoctorDays: 'डॉक्टर को पुनः दिखाने का समय',

    voiceTitle: 'बोलकर पूछें (Voice Healthcare Assistant)',
    voiceSubtitle: 'पढ़ने में कठिनाई हो रही है? माइक दबाकर अपनी भाषा में पूछें। AI तुरंत बोलकर समझाएगा।',
    tapToSpeak: 'बोलने के लिए माइक दबाएं',
    listeningNow: 'सुन रहे हैं... बोलिए',
    askDoctorQuestion: 'दवा के बारे में पूछें...',
    sampleQuestions: [
      'यह दवा किसलिए लेनी है?',
      'क्या यह दवा खाना खाने के बाद लेनी है?',
      'अगर एक खुराक छूट जाए तो क्या करें?',
      'मुझे सीने में बहुत तेज दर्द हो रहा है',
    ],
    safetyDisclaimer: 'सूचना: यह केवल सहायता मंच है। आपात स्थिति में तुरंत 108 पर कॉल करें या नजदीकी PHC जाएं।',

    remindersTitle: 'आज की दवाइयां व रिमाइंडर',
    remindersSubtitle: 'सही समय पर दवा लें और "दवा ले ली" बटन दबाएं।',
    morningSlot: 'सुबह (नाश्ते के बाद)',
    afternoonSlot: 'दोपहर (खाने के बाद)',
    nightSlot: 'रात (रात के खाने के बाद)',
    markAsTaken: 'दवा ले ली ✓',
    doseTaken: 'समय पर ली गई',
    adherenceScore: 'दवा नियमितता स्कोर',
    goodAdherenceMessage: 'बहुत बढ़िया! आप समय पर दवा ले रहे हैं।',

    emergencyTitle: 'आपातकालीन सहायता व स्वास्थ्य जानकारी',
    emergencySubtitle: 'बिना देर किए तुरंत सरकारी मुफ्त सहायता प्राप्त करें।',
    call108: '108 एम्बुलेंस (मुफ्त)',
    call104: '104 स्वास्थ्य सलाह हेल्पलाइन',
    phcDirectCall: 'नजदीकी PHC अस्पताल कॉल',
    redFlagsWarning: 'गंभीर लक्षण: सीने में भारीपन, सांस फूलना, बेहोशी - तुरंत 108 डायल करें!',
    orsGuideTitle: 'घर पर ORS घोल बनाने का तरीका',
    feverGuideTitle: 'मौसमी बुखार और डेंगू से बचाव',
    bpDiabetesGuideTitle: 'ब्लड प्रेशर और शुगर नियंत्रण के उपाय',
  },
  ta: {
    appTitle: 'ஆரோக்யசேது கிராமின்',
    appSubtitle: 'கிராமப்புற நோயாளிகளுக்கான பன்மொழி AI மருத்துவ உதவி',
    rolePatient: 'நோயாளி பயன்பாடு',
    roleAsha: 'ஆஷா களப்பணியாளர் போர்டல்',
    roleAdmin: 'PHC நிர்வாகம்',

    tabHome: 'முகப்பு',
    tabUpload: 'சீட்டு பதிவேற்றம்',
    tabVoice: 'குரல் உதவி (Voice)',
    tabReminders: 'மருந்து நினைவூட்டல்',
    tabHealthEdu: 'சுகாதார கல்வி & அவசர உதவி',
    tabAshaNotes: 'ஆஷா குறிப்புகள்',

    patientProfileTitle: 'நோயாளி அடையாள அட்டை',
    healthIdBadge: 'ABHA ஐடி',
    villageName: 'கிராமம்',
    phoneNumber: 'கைபேசி எண்',
    preferredLanguage: 'விருப்ப மொழி',
    switchPatient: 'நோயாளியை மாற்றவும்',
    newPatientRegistration: 'புதிய நோயாளி பதிவு',
    saveProfile: 'சேமிக்க',

    uploadTitle: 'மருத்துவர் மருந்து சீட்டை படம் எடுக்கவும் / பதிவேற்றவும்',
    uploadSubtitle: 'ஆங்கிலத்தில் உள்ள மருத்துவ குறிப்புகளை எளிமையான தமிழில் புரிந்து கொள்ளுங்கள்.',
    takePhoto: 'புகைப்படம் எடு',
    chooseFile: 'கோப்பை தேர்ந்தெடு',
    trySamplePrescription: 'மாதிரி PHC சீட்டைப் பார்க்கவும்',
    processingPrescription: 'AI மருந்து சீட்டை ஆராய்கிறது...',
    ocrExtracting: 'மருந்துகள், அளவுகள் பிரித்தெடுக்கப்படுகின்றன...',

    translationTitle: 'எளிய தமிழில் விளக்கம் மற்றும் மருந்து அளவு',
    doctorOriginal: 'மருத்துவரின் அசல் வழிமுறை (ஆங்கிலம்)',
    patientSimplified: 'எளிய தமிழ் விளக்கம்',
    listenToAudio: 'குரலில் கேட்க (Audio)',
    stopAudio: 'நிறுத்து',
    audioPlaying: 'குரல் ஒலிக்கிறது...',
    medicalTermsHeader: 'மருத்துவ சொற்களின் எளிய பொருள்',
    precautionsHeader: 'முக்கிய முன்னெச்சரிக்கைகள்',
    reviewDoctorDays: 'மீண்டும் பார்க்க வேண்டிய நாள்',

    voiceTitle: 'பேசி தெரிந்து கொள்ளுங்கள் (Voice Assistant)',
    voiceSubtitle: 'படிக்க சிரமமாக உள்ளதா? மைக் அழுத்தி உங்கள் தாய்மொழியில் கேளுங்கள்.',
    tapToSpeak: 'பேச மைக் அழுத்தவும்',
    listeningNow: 'கேட்கிறது... பேசுங்கள்',
    askDoctorQuestion: 'மருந்து பற்றி கேளுங்கள்...',
    sampleQuestions: [
      'இந்த மருந்தை ஏன் உட்கொள்ள வேண்டும்?',
      'சாப்பாட்டிற்குப் பின் சாப்பிட வேண்டுமா?',
      'மருந்து எடுக்க மறந்துவிட்டால் என்ன செய்ய வேண்டும்?',
      'நெஞ்சு வலி அதிகமாக உள்ளது',
    ],
    safetyDisclaimer: 'குறிப்பு: இது தகவல் உதவி மட்டுமே. அவசர நிலைக்கு உடனே 108 ஐ அழைக்கவும்.',

    remindersTitle: 'இன்றைய மருந்து அட்டவணை',
    remindersSubtitle: 'சரியான நேரத்தில் மருந்து உட்கொண்டு "உட்கொண்டேன்" என்பதை அழுத்தவும்.',
    morningSlot: 'காலை (சிற்றுண்டிக்கு பின்)',
    afternoonSlot: 'மதியம் (உணவுக்கு பின்)',
    nightSlot: 'இரவு (இரவு உணவுக்கு பின்)',
    markAsTaken: 'மருந்து உட்கொண்டேன் ✓',
    doseTaken: 'நேரத்திற்கு உட்கொள்ளப்பட்டது',
    adherenceScore: 'மருந்து தொடர்ச்சி நிலை',
    goodAdherenceMessage: 'மிக நன்று! தவறாமல் மருந்து எடுத்துக்கொள்கிறீர்கள்.',

    emergencyTitle: 'அவசர உதவி & கிராம சுகாதாரம்',
    emergencySubtitle: 'தாமதமின்றி உடனடியாக இலவச அரசு மருத்துவ உதவி பெறுங்கள்.',
    call108: '108 ஆம்புலன்ஸ் (இலவசம்)',
    call104: '104 சுகாதார ஆலோசனை',
    phcDirectCall: 'அருகிலுள்ள PHC அழைப்பு',
    redFlagsWarning: 'தீவிர எச்சரிக்கை அறிகுறிகள்: நெஞ்சு வலி, மூச்சுத்திணறல் - உடனே 108 அழையுங்கள்!',
    orsGuideTitle: 'வீட்டிலேயே ORS கரைசல் தயாரிப்பது எப்படி',
    feverGuideTitle: 'டெங்கு, காய்ச்சல் தடுப்பு முறைகள்',
    bpDiabetesGuideTitle: 'இரத்த அழுத்தம், சர்க்கரை நோய் கட்டுப்பாடு',
  },
  kn: {
    appTitle: 'ಆರೋಗ್ಯಸೇತು ಗ್ರಾಮೀಣ',
    appSubtitle: 'ಗ್ರಾಮೀಣ ರೋಗಿಗಳಿಗೆ ಬಹುಭಾಷಾ AI ಆರೋಗ್ಯ ಸಹಾಯ',
    rolePatient: 'ರೋಗಿ ಅಪ್ಲಿಕೇಶನ್',
    roleAsha: 'ಆಶಾ ಕಾರ್ಯಕರ್ತೆ ಪೋರ್ಟಲ್',
    roleAdmin: 'PHC ನಿರ್ವಾಹಕ',

    tabHome: 'ಮುಖಪುಟ',
    tabUpload: 'ಚೀಟಿ ಅಪ್‌ಲೋಡ್',
    tabVoice: 'ಧ್ವನಿ ಸಹಾಯ (Voice)',
    tabReminders: 'ಔಷಧ ಜ್ಞಾಪನೆ',
    tabHealthEdu: 'ಆರೋಗ್ಯ ಶಿಕ್ಷಣ & ತುರ್ತು',
    tabAshaNotes: 'ಆಶಾ ಫಾಲೋ-ಅಪ್',

    patientProfileTitle: 'ರೋಗಿ ಆರೋಗ್ಯ ಗುರುತಿನ ಚೀಟಿ',
    healthIdBadge: 'ABHA ಐಡಿ',
    villageName: 'ಗ್ರಾಮ',
    phoneNumber: 'ಮೊಬೈಲ್ ಸಂಖ್ಯೆ',
    preferredLanguage: 'ಆದ್ಯತೆಯ ಭಾಷೆ',
    switchPatient: 'ರೋಗಿ ಬದಲಾಯಿಸಿ',
    newPatientRegistration: 'ಹೊಸ ರೋಗಿ ನೋಂದಣಿ',
    saveProfile: 'ಉಳಿಸಿ',

    uploadTitle: 'ವೈದ್ಯರ ಪ್ರಿಸ್ಕ್ರಿಪ್ಷನ್ ಫೋಟೋ ತೆಗೆಯಿರಿ / ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
    uploadSubtitle: 'ಇಂಗ್ಲಿಷ್ ಚೀಟಿಯನ್ನು ಸರಳ ಕನ್ನಡದಲ್ಲಿ ಅರ್ಥಮಾಡಿಕೊಳ್ಳಿ.',
    takePhoto: 'ಫೋಟೋ ತೆಗೆಯಿರಿ',
    chooseFile: 'ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ',
    trySamplePrescription: 'ಮಾದರಿ PHC ಚೀಟಿ ಪರಿಶೀಲಿಸಿ',
    processingPrescription: 'AI ಚೀಟಿಯನ್ನು ಓದುತ್ತಿದೆ...',
    ocrExtracting: 'ಮಾಹಿತಿ ಹೊರತೆಗೆಯಲಾಗುತ್ತಿದೆ...',

    translationTitle: 'ಸರಳ ಕನ್ನಡದಲ್ಲಿ ವಿವರಣೆ ಮತ್ತು ಡೋಸ್',
    doctorOriginal: 'ವೈದ್ಯರ ಮೂಲ ಸೂಚನೆ (ಇಂಗ್ಲಿಷ್)',
    patientSimplified: 'ಸುಲಭ ಕನ್ನಡ ವಿವರಣೆ',
    listenToAudio: 'ಧ್ವನಿ ಆಲಿಸಿ (Audio)',
    stopAudio: 'ನಿಲ್ಲಿಸಿ',
    audioPlaying: 'ಧ್ವನಿ ಪ್ಲೇ ಆಗುತ್ತಿದೆ...',
    medicalTermsHeader: 'ವೈದ್ಯಕೀಯ ಪದಗಳ ಅರ್ಥ',
    precautionsHeader: 'ಮುಖ್ಯ ಮುನ್ನೆಚ್ಚರಿಕೆಗಳು',
    reviewDoctorDays: 'ಮತ್ತೆ ವೈದ್ಯರನ್ನು ಭೇಟಿಯಾಗಬೇಕಾದ ದಿನ',

    voiceTitle: 'ಧ್ವನಿ ಸಹಾಯ (Voice Assistant)',
    voiceSubtitle: 'ಓದಲು ಕಷ್ಟವೇ? ಮೈಕ್ ಒತ್ತಿ ನಿಮ್ಮ ಪ್ರಶ್ನೆಯನ್ನು ಕೇಳಿ.',
    tapToSpeak: 'ಮಾತನಾಡಲು ಮೈಕ್ ಒತ್ತಿ',
    listeningNow: 'ಕೇಳುತ್ತಿದ್ದೇವೆ... ಮಾತನಾಡಿ',
    askDoctorQuestion: 'ಔಷಧದ ಬಗ್ಗೆ ಕೇಳಿ...',
    sampleQuestions: [
      'ಈ ಔಷಧಿಯನ್ನು ಏಕೆ ತೆಗೆದುಕೊಳ್ಳಬೇಕು?',
      'ಊಟದ ನಂತರ ತೆಗೆದುಕೊಳ್ಳಬೇಕೆ?',
      'ಔಷಧಿ ತೆಗೆದುಕೊಳ್ಳಲು ಮರೆತರೆ ಏನು ಮಾಡಬೇಕು?',
      'ಎದೆ ನೋವು ಹೆಚ್ಚಾಗಿದೆ',
    ],
    safetyDisclaimer: 'ಸೂಚನೆ: ತುರ್ತು ಪರಿಸ್ಥಿತಿಯಲ್ಲಿ ತಕ್ಷಣ 108 ಗೆ ಕರೆ ಮಾಡಿ.',

    remindersTitle: 'ಇಂದಿನ ಔಷಧ ವೇಳಾಪಟ್ಟಿ',
    remindersSubtitle: 'ಸಮಯಕ್ಕೆ ಸರಿಯಾಗಿ ಔಷಧಿ ತೆಗೆದುಕೊಳ್ಳಿ.',
    morningSlot: 'ಬೆಳಗ್ಗೆ (ಉಪಾಹಾರದ ನಂತರ)',
    afternoonSlot: 'ಮಧ್ಯಾಹ್ನ (ಊಟದ ನಂತರ)',
    nightSlot: 'ರಾತ್ರಿ (ರಾತ್ರಿ ಊಟದ ನಂತರ)',
    markAsTaken: 'ಔಷಧಿ ತೆಗೆದುಕೊಂಡೆ ✓',
    doseTaken: 'ಸಮಯಕ್ಕೆ ತೆಗೆದುಕೊಂಡಿದ್ದೀರಿ',
    adherenceScore: 'ಔಷಧ ನಿಷ್ಠೆ ಸ್ಕೋರ್',
    goodAdherenceMessage: 'ಉತ್ತಮ! ನೀವು ನಿಯಮಿತವಾಗಿ ಔಷಧಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತಿದ್ದೀರಿ.',

    emergencyTitle: 'ತುರ್ತು ನೆರವು & ಆರೋಗ್ಯ ಮಾಹಿತಿ',
    emergencySubtitle: 'ತಕ್ಷಣ ಉಚಿತ ಸರ್ಕಾರಿ ನೆರವು ಪಡೆಯಿರಿ.',
    call108: '108 ಆಂಬ್ಯುಲೆನ್ಸ್ (ಉಚಿತ)',
    call104: '104 ಆರೋಗ್ಯ ಸಹಾಯವಾಣಿ',
    phcDirectCall: 'ಸಮೀಪದ PHC ಕರೆ',
    redFlagsWarning: 'ತುರ್ತು ಚಿಹ್ನೆಗಳು: ಎದೆ ನೋವು, ಉಸಿರಾಟದ ತೊಂದರೆ - 108 ಗೆ ಕರೆ ಮಾಡಿ!',
    orsGuideTitle: 'ಮನೆಯಲ್ಲಿಯೇ ORS ದ್ರಾವಣ ತಯಾರಿಕೆ',
    feverGuideTitle: 'ಡೆಂಗ್ಯೂ ಮತ್ತು ಜ್ವರ ತಡೆಗಟ್ಟುವಿಕೆ',
    bpDiabetesGuideTitle: 'ರಕ್ತದೊತ್ತಡ ಮತ್ತು ಮಧುಮೇಹ ನಿಯಂತ್ರಣ',
  },
  bn: {
    appTitle: 'আরোগ্যসেতু গ্রামীণ',
    appSubtitle: 'গ্রামীণ রোগীদের জন্য বহুভাষিক AI স্বাস্থ্য সহকারী',
    rolePatient: 'রোগী অ্যাপ্লিকেশন',
    roleAsha: 'আশা কর্মী পোর্টাল',
    roleAdmin: 'PHC অ্যাডমিন',

    tabHome: 'হোম',
    tabUpload: 'প্রেসক্রিপশন আপলোড',
    tabVoice: 'ভয়েস সহায়ক (Voice)',
    tabReminders: 'ওষুধের রিমাইন্ডার',
    tabHealthEdu: 'স্বাস্থ্য শিক্ষা ও জরুরি সেবা',
    tabAshaNotes: 'আশা ফলো-আপ',

    patientProfileTitle: 'রোগীর স্বাস্থ্য পরিচয়পত্র',
    healthIdBadge: 'ABHA আইডি',
    villageName: 'গ্রাম',
    phoneNumber: 'ফোন নম্বর',
    preferredLanguage: 'পছন্দের ভাষা',
    switchPatient: 'রোগী পরিবর্তন করুন',
    newPatientRegistration: 'নতুন রোগী নিবন্ধন',
    saveProfile: 'সংরক্ষণ করুন',

    uploadTitle: 'প্রেসক্রিপশনের ছবি তুলুন বা আপলোড করুন',
    uploadSubtitle: 'ইংরেজি প্রেসক্রিপশন সহজ বাংলায় বুঝে নিন।',
    takePhoto: 'ছবি তুলুন',
    chooseFile: 'ফাইল বাছুন',
    trySamplePrescription: 'নমুনা PHC প্রেসক্রিপশন দেখুন',
    processingPrescription: 'AI প্রেসক্রিপশন পড়ছে...',
    ocrExtracting: 'তথ্য সংগ্রহ করা হচ্ছে...',

    translationTitle: 'সহজ বাংলায় ওষুধের মাত্রা ও সময়',
    doctorOriginal: 'ডাক্তারের আসল নির্দেশ (ইংরেজি)',
    patientSimplified: 'সহজ বাংলা ব্যাখ্যা',
    listenToAudio: 'শব্দ শুনুন (Audio)',
    stopAudio: 'থামুন',
    audioPlaying: 'শব্দ বাজছে...',
    medicalTermsHeader: 'চিকিৎসা শব্দের সহজ অর্থ',
    precautionsHeader: 'জরুরি সতর্কতা',
    reviewDoctorDays: 'আবার ডাক্তার দেখানোর সময়',

    voiceTitle: 'কথা বলে জানুন (Voice Assistant)',
    voiceSubtitle: 'পড়তে সমস্যা? মাইক টিপে বাংলায় আপনার প্রশ্ন জিজ্ঞাসা করুন।',
    tapToSpeak: 'কথা বলতে মাইক চাপুন',
    listeningNow: 'শুনছি... বলুন',
    askDoctorQuestion: 'ওষুধ সম্পর্কে জানুন...',
    sampleQuestions: [
      'এই ওষুধটি কেন খেতে হবে?',
      'খাবারের পরে না আগে খেতে হবে?',
      'ওষুধ খেতে ভুলে গেলে কি করণীয়?',
      'বুকে খুব ব্যথা হচ্ছে',
    ],
    safetyDisclaimer: 'জরুরি অবস্থায় অবিলম্বে ১০৮ নম্বরে ফোন করুন।',

    remindersTitle: 'আজকের ওষুধের রুটিন',
    remindersSubtitle: 'সঠিক সময়ে ওষুধ খেয়ে "খেয়েছি" বোতাম চাপুন।',
    morningSlot: 'সকাল (প্রাতরাশের পর)',
    afternoonSlot: 'দুপুর (দুপুরের খাবারের পর)',
    nightSlot: 'রাত (রাতের খাবারের পর)',
    markAsTaken: 'ওষুধ খেয়েছি ✓',
    doseTaken: 'সময়মতো খাওয়া হয়েছে',
    adherenceScore: 'ওষুধ সেবনের নিয়মিততা',
    goodAdherenceMessage: 'খুব ভালো! আপনি নিয়মিত ওষুধ খাচ্ছেন।',

    emergencyTitle: 'জরুরি সাহায্য ও স্বাস্থ্য তথ্য',
    emergencySubtitle: 'বিনা খরচে সরকারি স্বাস্থ্য সাহায্য নিন।',
    call108: '১০৮ অ্যাম্বুলেন্স (বিনামূল্যে)',
    call104: '১০৪ স্বাস্থ্য হেল্পলাইন',
    phcDirectCall: 'কাছের PHC হাসপাতালে কল',
    redFlagsWarning: 'মারাত্মক লক্ষণ: বুকে ব্যথা, শ্বাসকষ্ট - তৎক্ষণাৎ ১০৮ এ কল দিন!',
    orsGuideTitle: 'বাড়িতে ORS স্যালাইন তৈরির নিয়ম',
    feverGuideTitle: 'ডেঙ্গু ও সাধারণ জ্বর প্রতিরোধ',
    bpDiabetesGuideTitle: 'রক্তচাপ ও ডায়াবেটিস নিয়ন্ত্রণ',
  },
  en: {
    appTitle: 'ArogyaSetu Rural',
    appSubtitle: 'AI Multilingual Healthcare Support for Rural Patients & Health Workers',
    rolePatient: 'Patient App',
    roleAsha: 'ASHA Health Worker Portal',
    roleAdmin: 'PHC Admin Dashboard',

    tabHome: 'Overview & Profile',
    tabUpload: 'Prescription OCR',
    tabVoice: 'Voice Assistant',
    tabReminders: 'Medication Reminders',
    tabHealthEdu: 'Education & SOS',
    tabAshaNotes: 'Community Follow-Up',

    patientProfileTitle: 'Patient Health ID Card',
    healthIdBadge: 'ABHA Health ID',
    villageName: 'Village',
    phoneNumber: 'Mobile Number',
    preferredLanguage: 'Language',
    switchPatient: 'Switch Patient',
    newPatientRegistration: 'Register New Patient',
    saveProfile: 'Save Profile',

    uploadTitle: 'Upload / Photograph Doctor Prescription',
    uploadSubtitle: 'Extracts English clinical handwriting & translates doctor instructions into patient regional language without altering dosage.',
    takePhoto: 'Take Photo',
    chooseFile: 'Select File / PDF',
    trySamplePrescription: 'Load PHC Sample Prescription (Telangana / Maharashtra)',
    processingPrescription: 'AI reading handwriting & verifying clinical instructions...',
    ocrExtracting: 'Extracting medicine names, dosages, timings, food instructions...',

    translationTitle: 'Simplified Vernacular Explanation & Dosage',
    doctorOriginal: 'Doctor Written Instructions (English)',
    patientSimplified: 'Patient Plain-Language Explanation',
    listenToAudio: 'Listen Aloud (Audio TTS)',
    stopAudio: 'Stop Audio',
    audioPlaying: 'Audio playing...',
    medicalTermsHeader: 'Medical Terms Explained in Simple Language',
    precautionsHeader: 'Important Doctor Precautions',
    reviewDoctorDays: 'Follow-Up Review at PHC in',

    voiceTitle: 'Voice Healthcare Assistant (Speak & Listen)',
    voiceSubtitle: 'Patients with limited reading literacy can speak into the microphone. AI answers questions in regional voice.',
    tapToSpeak: 'Tap Microphone to Speak',
    listeningNow: 'Listening... Please speak in your language',
    askDoctorQuestion: 'Ask a question about your medicines...',
    sampleQuestions: [
      'Why should I use this medicine?',
      'Should I take this before or after meals?',
      'What should I do if I missed a morning dose?',
      'I am having sudden severe crushing chest pain',
    ],
    safetyDisclaimer: 'Notice: This is a healthcare support platform, NOT an AI doctor. It never diagnoses or alters dosages. For emergencies, call 108.',

    remindersTitle: 'Today’s Verified Medication Schedule',
    remindersSubtitle: 'Take medicines at scheduled hours and tap "Mark as Taken" to record adherence.',
    morningSlot: 'Morning (After breakfast)',
    afternoonSlot: 'Afternoon (After lunch)',
    nightSlot: 'Night (After dinner)',
    markAsTaken: 'Mark as Taken ✓',
    doseTaken: 'Dose Recorded',
    adherenceScore: 'Medication Adherence Score',
    goodAdherenceMessage: 'Excellent adherence! You are taking medicines on time.',

    emergencyTitle: 'Emergency Assistance & Village Health Education',
    emergencySubtitle: 'Direct one-tap dials to government emergency helplines and rural health advisories.',
    call108: '108 Ambulance (Toll-Free)',
    call104: '104 Health Helpline',
    phcDirectCall: 'Call Narsampet PHC Doctor',
    redFlagsWarning: 'Red-Flag Emergency Symptoms: Severe chest pain, sudden breathlessness, collapse - dial 108 immediately!',
    orsGuideTitle: 'How to prepare homemade ORS with boiled water, salt & sugar',
    feverGuideTitle: 'Seasonal fevers, mosquito prevention & dengue care',
    bpDiabetesGuideTitle: 'Managing High Blood Pressure & Blood Sugar in rural routine',
  },
};
