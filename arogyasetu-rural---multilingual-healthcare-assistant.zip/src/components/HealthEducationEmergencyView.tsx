import React, { useState } from 'react';
import { ShieldAlert, PhoneCall, AlertTriangle, Droplet, Heart, Thermometer, Baby, ChevronDown, ChevronUp, Volume2 } from 'lucide-react';
import { SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../translations';
import { speechManager } from '../utils/audio';

interface HealthEducationEmergencyViewProps {
  currentLanguage: SupportedLanguage;
}

export const HealthEducationEmergencyView: React.FC<HealthEducationEmergencyViewProps> = ({
  currentLanguage,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const [expandedGuide, setExpandedGuide] = useState<string | null>('ors');

  const emergencyContacts = [
    {
      title: t.call108,
      number: '108',
      desc: 'Free 24x7 Emergency Ambulance Service (ప్రభుత్వ ఉచిత అంబులెన్స్)',
      bg: 'bg-rose-700 hover:bg-rose-800 text-white',
    },
    {
      title: t.call104,
      number: '104',
      desc: 'Free Tele-Health Medical Advice & PHC Support (వైద్య సలహా)',
      bg: 'bg-stone-900 hover:bg-stone-800 text-white',
    },
    {
      title: t.phcDirectCall,
      number: '08718-245100',
      desc: 'Narsampet Primary Health Centre Duty Medical Officer',
      bg: 'bg-emerald-700 hover:bg-emerald-800 text-white',
    },
  ];

  const guides = [
    {
      id: 'ors',
      title: t.orsGuideTitle,
      icon: Droplet,
      iconColor: 'text-blue-600 bg-blue-100',
      summary: 'అతిసార లేదా నీళ్ల విరేచనాలు అయినప్పుడు డీహైడ్రేషన్ రాకుండా ప్రాణాలు కాపాడే జీవన ద్రావణం.',
      content: `1. ఒక పాత్రలో ఒక లీటర్ శుభ్రమైన నీటిని బాగా కాచి చల్లార్చండి.
2. అందులో అర (1/2) చెంచా ఉప్పు మరియు ఆరు (6) చిన్న చెంచాల పంచదార కలపండి.
3. పంచదార మరియు ఉప్పు పూర్తిగా కరిగిపోయేంతవరకు బాగా కలపండి.
4. విరేచనాలు అయిన ప్రతిసారీ పెద్దలకు ఒక గ్లాసు, పిల్లలకు అర గ్లాసు చొప్పున తాగించండి.
గమనిక: కలిపిన 24 గంటల తర్వాత మిగిలిన ద్రావణాన్ని పారబోసి, మరుసటి రోజు తాజాగా కలుపుకోవాలి.`,
    },
    {
      id: 'fever',
      title: t.feverGuideTitle,
      icon: Thermometer,
      iconColor: 'text-amber-600 bg-amber-100',
      summary: 'వర్షాకాలంలో డెంగ్యూ, మలేరియా రాకుండా గ్రామ పరిసరాలను శుభ్రంగా ఉంచుకోవడం.',
      content: `1. ఇళ్ల చుట్టూ ఉన్న కొబ్బరి బొండాలు, పాత టైర్లు, రోళ్లు మరియు తొట్లలో నీరు నిల్వ ఉండకుండా వారానికి ఒకసారి ఖాళీ చేసి ఆరబెట్టండి (డ్రై డే పాటించండి).
2. నీటి తొట్లు, డ్రమ్ములపై మూతలు తప్పనిసరిగా ఉంచండి.
3. నిద్రపోయేటప్పుడు దోమతెరలు (Bed nets) ఉపయోగించండి.
4. మూడు రోజులకు మించి తీవ్రమైన జ్వరం, కళ్ళ వెనుక నొప్పి ఉంటే వెంటనే PHC కి వెళ్లి రక్త పరీక్ష చేయించుకోండి.`,
    },
    {
      id: 'bp_diabetes',
      title: t.bpDiabetesGuideTitle,
      icon: Heart,
      iconColor: 'text-rose-600 bg-rose-100',
      summary: 'రక్తపోటు (బీపీ) మరియు షుగర్‌ను జీవనశైలి మార్పులతో సాధారణ స్థితిలో ఉంచడం.',
      content: `1. కూరల్లో ఉప్పు మరియు నూనె తగ్గించండి. పచ్చళ్ళు, అప్పడాలు, వేపుళ్ళు తగ్గించాలి.
2. రోజూ ఉదయం లేదా సాయంత్రం 30 నిమిషాలు వేగంగా నడవండి.
3. వైద్యులు రాసిన బీపీ మరియు షుగర్ మందులను ఒకరోజు కూడా మానకూడదు. బీపీ అదుపులో ఉన్నా మందు ఆపకూడదు.
4. నెలకు ఒకసారి గ్రామ ఉపకేంద్రంలో ఏఎన్‌ఎం లేదా ఆశా కార్యకర్త ద్వారా బీపీ, షుగర్ తనిఖీ చేయించుకోండి.`,
    },
    {
      id: 'maternal',
      title: 'గర్భిణీ స్త్రీలు & శిశు పోషణ మార్గదర్శకాలు',
      icon: Baby,
      iconColor: 'text-emerald-600 bg-emerald-100',
      summary: 'తల్లీబిడ్డల సంరక్షణ, ఐరన్ మాత్రలు మరియు పౌష్టికాహారం.',
      content: `1. గర్భం దాల్చిన వెంటనే అంగన్‌వాడీ లేదా ప్రాథమిక ఆరోగ్య కేంద్రంలో పేరు నమోదు చేసుకోండి.
2. ప్రభుత్వం ఉచితంగా ఇచ్చే ఐరన్ & ఫోలిక్ యాసిడ్ (IFA) మాత్రలను రోజూ రాత్రి భోజనం తర్వాత వేసుకోండి.
3. ఆకుకూరలు, కోడిగుడ్లు, పప్పుధాన్యాలు, బెల్లం మరియు పాలు రోజూ ఆహారంలో ఉండేలా చూసుకోండి.
4. ఆసుపత్రి కాన్పు మాత్రమే చేయించుకోండి (102 లేదా 108 వాహనం ఉచితం).`,
    },
  ];

  const handleSpeakGuide = (title: string, content: string) => {
    speechManager.speak(`${title}. ${content}`, currentLanguage);
  };

  return (
    <div className="space-y-6">
      {/* Emergency Section */}
      <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-rose-950">
              {t.emergencyTitle}
            </h2>
            <p className="text-xs text-rose-800">
              {t.emergencySubtitle}
            </p>
          </div>
        </div>

        {/* Red Flag Warning Box */}
        <div className="my-4 p-3 bg-white/90 rounded-xl border border-rose-200 text-xs text-rose-900 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <p className="font-semibold font-indic leading-relaxed">
            {t.redFlagsWarning}
          </p>
        </div>

        {/* Emergency Call Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {emergencyContacts.map((c, idx) => (
            <a
              key={idx}
              href={`tel:${c.number}`}
              className={`p-4 rounded-xl flex flex-col justify-between transition-transform active:scale-98 shadow-sm ${c.bg}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold">{c.title}</span>
                <PhoneCall className="w-4 h-4" />
              </div>
              <span className="text-2xl font-black tracking-tight font-mono my-2">
                {c.number}
              </span>
              <span className="text-[11px] opacity-85 leading-tight">
                {c.desc}
              </span>
            </a>
          ))}
        </div>
      </div>

      {/* Health Education Guides */}
      <div className="bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="border-b border-stone-200 pb-3">
          <h3 className="text-base font-bold text-stone-900">
            గ్రామ ఆరోగ్య విద్య & నివారణ సూచనలు (Preventive Health Guides)
          </h3>
          <p className="text-xs text-stone-500">
            సాధారణ గ్రామీణ సమస్యలు, పరిశుభ్రత మరియు పోషకాహార సమగ్ర సమాచారం.
          </p>
        </div>

        <div className="space-y-3">
          {guides.map((g) => {
            const isExpanded = expandedGuide === g.id;
            const Icon = g.icon;

            return (
              <div
                key={g.id}
                className="border border-stone-200 rounded-xl overflow-hidden transition-all"
              >
                <button
                  onClick={() => setExpandedGuide(isExpanded ? null : g.id)}
                  className="w-full p-4 bg-stone-50/70 hover:bg-stone-100 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${g.iconColor}`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-stone-900 font-indic">
                        {g.title}
                      </h4>
                      <p className="text-xs text-stone-500 line-clamp-1 font-indic">
                        {g.summary}
                      </p>
                    </div>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-stone-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-stone-400 shrink-0" />
                  )}
                </button>

                {isExpanded && (
                  <div className="p-4 bg-white border-t border-stone-200 space-y-3 text-xs leading-relaxed text-stone-800 font-indic">
                    <div className="flex justify-end">
                      <button
                        onClick={() => handleSpeakGuide(g.title, g.content)}
                        className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg font-semibold flex items-center gap-1.5 transition-colors border border-emerald-200"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-emerald-700" />
                        <span>ఆడియో వినండి (Listen)</span>
                      </button>
                    </div>

                    <div className="whitespace-pre-line bg-stone-50 p-3.5 rounded-xl border border-stone-100 font-medium text-stone-700">
                      {g.content}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
