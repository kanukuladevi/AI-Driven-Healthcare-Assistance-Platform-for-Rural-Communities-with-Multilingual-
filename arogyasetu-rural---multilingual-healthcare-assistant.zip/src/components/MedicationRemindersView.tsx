import React, { useState } from 'react';
import { Clock, CheckCircle2, Circle, AlertCircle, Sun, CloudSun, Moon, Volume2, Award, Pill } from 'lucide-react';
import { MedicationReminder, SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../translations';
import { speechManager } from '../utils/audio';

interface MedicationRemindersViewProps {
  reminders: MedicationReminder[];
  onToggleReminder: (reminderId: string) => Promise<void>;
  currentLanguage: SupportedLanguage;
}

export const MedicationRemindersView: React.FC<MedicationRemindersViewProps> = ({
  reminders,
  onToggleReminder,
  currentLanguage,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const [filterSlot, setFilterSlot] = useState<'All' | 'Morning' | 'Afternoon' | 'Night'>('All');
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const total = reminders.length;
  const takenCount = reminders.filter((r) => r.takenToday).length;
  const adherencePercentage = total > 0 ? Math.round((takenCount / total) * 100) : 100;

  const filteredReminders = reminders.filter((r) => {
    if (filterSlot === 'All') return true;
    return r.timeSlot === filterSlot;
  });

  const handleToggle = async (reminder: MedicationReminder) => {
    setLoadingId(reminder.id);
    try {
      await onToggleReminder(reminder.id);
      // Play celebratory chime when marking as taken
      if (!reminder.takenToday) {
        speechManager.playChime(true);
      }
    } finally {
      setLoadingId(null);
    }
  };

  const speakReminder = (r: MedicationReminder) => {
    const text = `${r.medicineName}, ${r.dosage}. సమయం: ${r.scheduledTime}, ${r.relationToFood}.`;
    speechManager.speak(text, currentLanguage);
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 shadow-xs space-y-6">
      {/* Title & Adherence Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Clock className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-stone-900 tracking-tight">
              {t.remindersTitle}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-stone-600">
            {t.remindersSubtitle}
          </p>
        </div>

        {/* Adherence Progress Pill / Metric */}
        <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 flex items-center gap-4 shrink-0">
          <div className="relative w-12 h-12 flex items-center justify-center">
            <svg className="w-12 h-12 -rotate-90">
              <circle
                cx="24"
                cy="24"
                r="20"
                className="stroke-stone-200 fill-none"
                strokeWidth="4"
              />
              <circle
                cx="24"
                cy="24"
                r="20"
                className="stroke-emerald-600 fill-none transition-all duration-500"
                strokeWidth="4"
                strokeDasharray={125.6}
                strokeDashoffset={125.6 - (125.6 * adherencePercentage) / 100}
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute text-xs font-bold text-stone-900 font-mono">
              {adherencePercentage}%
            </span>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-emerald-600" />
              <span className="text-xs font-bold text-stone-800">
                {t.adherenceScore}
              </span>
            </div>
            <p className="text-[11px] text-stone-500">
              {takenCount} of {total} doses completed today
            </p>
          </div>
        </div>
      </div>

      {/* Filter Tabs (Interactive Segmented Control) */}
      <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-xl max-w-md">
        <button
          onClick={() => setFilterSlot('All')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors text-center ${
            filterSlot === 'All'
              ? 'bg-white text-stone-900 shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          All ({total})
        </button>
        <button
          onClick={() => setFilterSlot('Morning')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1 ${
            filterSlot === 'Morning'
              ? 'bg-white text-stone-900 shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Sun className="w-3 h-3 text-amber-500" />
          <span>Morning</span>
        </button>
        <button
          onClick={() => setFilterSlot('Afternoon')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1 ${
            filterSlot === 'Afternoon'
              ? 'bg-white text-stone-900 shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <CloudSun className="w-3 h-3 text-amber-600" />
          <span>Afternoon</span>
        </button>
        <button
          onClick={() => setFilterSlot('Night')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1 ${
            filterSlot === 'Night'
              ? 'bg-white text-stone-900 shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Moon className="w-3 h-3 text-blue-500" />
          <span>Night</span>
        </button>
      </div>

      {/* Reminders List */}
      <div className="space-y-3">
        {filteredReminders.length === 0 ? (
          <div className="p-8 text-center bg-stone-50 rounded-xl border border-dashed border-stone-300">
            <Pill className="w-8 h-8 text-stone-400 mx-auto mb-2" />
            <p className="text-xs text-stone-600 font-medium">
              No medications scheduled for this time slot
            </p>
          </div>
        ) : (
          filteredReminders.map((rem) => {
            const isTaken = rem.takenToday;

            return (
              <div
                key={rem.id}
                className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  isTaken
                    ? 'bg-emerald-50/50 border-emerald-200 opacity-90'
                    : 'bg-white border-stone-200 hover:border-emerald-300 shadow-2xs'
                }`}
              >
                {/* Left Info */}
                <div className="flex items-start gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      rem.timeSlot === 'Morning'
                        ? 'bg-amber-100 text-amber-800'
                        : rem.timeSlot === 'Afternoon'
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {rem.timeSlot === 'Morning' ? (
                      <Sun className="w-5 h-5" />
                    ) : rem.timeSlot === 'Afternoon' ? (
                      <CloudSun className="w-5 h-5" />
                    ) : (
                      <Moon className="w-5 h-5" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4
                        className={`text-sm sm:text-base font-bold ${
                          isTaken ? 'line-through text-stone-500' : 'text-stone-900'
                        }`}
                      >
                        {rem.medicineName}
                      </h4>
                      <span className="text-xs font-mono font-semibold px-2 py-0.5 bg-stone-100 rounded text-stone-700">
                        {rem.dosage}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 mt-1">
                      <span className="font-semibold text-emerald-800">
                        {rem.scheduledTime}
                      </span>
                      <span>·</span>
                      <span className="font-indic">{rem.relationToFood}</span>
                      {isTaken && rem.takenAt && (
                        <>
                          <span>·</span>
                          <span className="text-emerald-700 font-semibold">
                            Recorded at {rem.takenAt}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Action Controls: Audio + Big Mark as Taken Hitbox */}
                <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                  <button
                    onClick={() => speakReminder(rem)}
                    className="w-10 h-10 rounded-xl bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-600 transition-colors"
                    title="Listen Reminder"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleToggle(rem)}
                    disabled={loadingId === rem.id}
                    className={`min-h-[44px] min-w-[150px] px-4 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-98 ${
                      isTaken
                        ? 'bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-300'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                    }`}
                  >
                    {isTaken ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>{t.doseTaken}</span>
                      </>
                    ) : (
                      <>
                        <Circle className="w-4 h-4" />
                        <span>{t.markAsTaken}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Encouragement Footer */}
      <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-950 flex items-center gap-2">
        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
        <span className="font-medium font-indic">{t.goodAdherenceMessage}</span>
      </div>
    </div>
  );
};
