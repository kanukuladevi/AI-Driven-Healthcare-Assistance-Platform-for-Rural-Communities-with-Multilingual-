import React from 'react';
import { Volume2, VolumeX, ShieldAlert, User, HeartHandshake, Building2, Languages } from 'lucide-react';
import { SupportedLanguage, LANGUAGES, Patient } from '../types';
import { TRANSLATIONS } from '../translations';
import { speechManager } from '../utils/audio';

interface HeaderProps {
  currentLanguage: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  activeRole: 'patient' | 'asha' | 'admin';
  onRoleChange: (role: 'patient' | 'asha' | 'admin') => void;
  activePatient: Patient | null;
  onOpenProfile: () => void;
  isAudioSpeaking: boolean;
  onStopAudio: () => void;
  onOpenEmergency: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLanguage,
  onLanguageChange,
  activeRole,
  onRoleChange,
  activePatient,
  onOpenProfile,
  isAudioSpeaking,
  onStopAudio,
  onOpenEmergency,
}) => {
  const t = TRANSLATIONS[currentLanguage];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold shadow-sm shadow-emerald-700/20">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold tracking-tight text-stone-900 whitespace-nowrap">
                {t.appTitle}
              </span>
              <span className="hidden sm:inline-block text-xs font-semibold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md">
                గ్రామీణ సేవ
              </span>
            </div>
            <p className="text-xs text-stone-500 hidden md:block">
              {t.appSubtitle}
            </p>
          </div>
        </div>

        {/* Center Zone: Role Switcher Tabs */}
        <div className="hidden lg:flex items-center p-1 bg-stone-100 rounded-xl border border-stone-200">
          <button
            onClick={() => onRoleChange('patient')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeRole === 'patient'
                ? 'bg-white text-emerald-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>{t.rolePatient}</span>
          </button>
          <button
            onClick={() => onRoleChange('asha')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeRole === 'asha'
                ? 'bg-white text-emerald-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>{t.roleAsha}</span>
          </button>
          <button
            onClick={() => onRoleChange('admin')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeRole === 'admin'
                ? 'bg-white text-emerald-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>{t.roleAdmin}</span>
          </button>
        </div>

        {/* Action Zone: Audio Controller + Language Selector + Emergency + Profile */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Audio Speaking Indicator & Stop button */}
          {isAudioSpeaking && (
            <button
              onClick={onStopAudio}
              className="px-2.5 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors border border-amber-300 animate-pulse"
              title="Stop voice"
            >
              <VolumeX className="w-3.5 h-3.5 text-amber-800" />
              <span className="hidden sm:inline">{t.stopAudio}</span>
            </button>
          )}

          {/* Emergency SOS Button */}
          <button
            onClick={onOpenEmergency}
            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors shrink-0"
          >
            <ShieldAlert className="w-4 h-4" />
            <span className="hidden sm:inline">108 SOS</span>
            <span className="sm:hidden">108</span>
          </button>

          {/* Multilingual Selector */}
          <div className="relative flex items-center">
            <select
              value={currentLanguage}
              onChange={(e) => onLanguageChange(e.target.value as SupportedLanguage)}
              className="bg-stone-100 hover:bg-stone-200 border border-stone-300 text-stone-800 text-xs font-semibold rounded-lg py-1.5 pl-2.5 pr-7 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden cursor-pointer"
              aria-label="Select Language"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName} ({l.name})
                </option>
              ))}
            </select>
          </div>

          {/* Active Patient Pill / Switcher */}
          {activePatient && (
            <button
              onClick={onOpenProfile}
              className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 border border-stone-200 rounded-lg text-xs font-medium text-stone-800 flex items-center gap-2 transition-colors shrink-0"
            >
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold">
                {activePatient.name.charAt(0)}
              </div>
              <span className="hidden md:inline font-semibold">{activePatient.name}</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Role Switcher Bar */}
      <div className="lg:hidden flex border-t border-stone-200 bg-stone-50 px-2 py-1.5 justify-around">
        <button
          onClick={() => onRoleChange('patient')}
          className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${
            activeRole === 'patient'
              ? 'bg-emerald-600 text-white font-semibold'
              : 'text-stone-600'
          }`}
        >
          {t.rolePatient}
        </button>
        <button
          onClick={() => onRoleChange('asha')}
          className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${
            activeRole === 'asha'
              ? 'bg-emerald-600 text-white font-semibold'
              : 'text-stone-600'
          }`}
        >
          {t.roleAsha}
        </button>
        <button
          onClick={() => onRoleChange('admin')}
          className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${
            activeRole === 'admin'
              ? 'bg-emerald-600 text-white font-semibold'
              : 'text-stone-600'
          }`}
        >
          {t.roleAdmin}
        </button>
      </div>
    </header>
  );
};
