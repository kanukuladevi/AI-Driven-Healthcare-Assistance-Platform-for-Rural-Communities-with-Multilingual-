import React, { useState } from 'react';
import { Volume2, VolumeX, ShieldCheck, Clock, Calendar, AlertTriangle, Pill, HeartPulse, Check, Info } from 'lucide-react';
import { PrescriptionRecord, SupportedLanguage, MedicationItem } from '../types';
import { TRANSLATIONS } from '../translations';
import { speechManager } from '../utils/audio';

interface PrescriptionDetailCardProps {
  prescription: PrescriptionRecord;
  currentLanguage: SupportedLanguage;
  onAddToReminders?: () => void;
}

export const PrescriptionDetailCard: React.FC<PrescriptionDetailCardProps> = ({
  prescription,
  currentLanguage,
  onAddToReminders,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const [activeSpeakingMedId, setActiveSpeakingMedId] = useState<string | null>(null);
  const [isSpeakingFull, setIsSpeakingFull] = useState(false);
  const [remindersAdded, setRemindersAdded] = useState(false);

  // Play audio readout for a single medication
  const handleSpeakMedication = (med: MedicationItem) => {
    if (activeSpeakingMedId === med.id) {
      speechManager.stop();
      setActiveSpeakingMedId(null);
      return;
    }

    speechManager.stop();
    setActiveSpeakingMedId(med.id);
    const textToSpeak = `${med.medicineName}. ${med.simplifiedExplanation}. ${med.precautions}`;

    speechManager.speak(
      textToSpeak,
      currentLanguage,
      () => setActiveSpeakingMedId(med.id),
      () => setActiveSpeakingMedId(null)
    );
  };

  // Play audio readout for the whole prescription overview
  const handleSpeakFullOverview = () => {
    if (isSpeakingFull) {
      speechManager.stop();
      setIsSpeakingFull(false);
      return;
    }

    speechManager.stop();
    setIsSpeakingFull(true);

    const medsSummary = prescription.medications
      .map((m) => `${m.medicineName}: ${m.simplifiedExplanation}`)
      .join('. ');

    const fullText = `డాక్టర్ సూచించిన ప్రిస్క్రిప్షన్ వివరాలు. జబ్బు: ${prescription.diagnosisExplanation || prescription.diagnosis}. మందుల వివరాలు: ${medsSummary}. డాక్టర్ సలహా: ${prescription.doctorAdvice}.`;

    speechManager.speak(
      fullText,
      currentLanguage,
      () => setIsSpeakingFull(true),
      () => setIsSpeakingFull(false)
    );
  };

  const handleAddRemindersClick = () => {
    if (onAddToReminders) onAddToReminders();
    setRemindersAdded(true);
    speechManager.playChime(true);
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
      {/* Clinic & Doctor Banner */}
      <div className="bg-stone-900 text-white p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded border border-emerald-400/30">
                Government PHC Verified
              </span>
              <span className="text-xs text-stone-400">· {prescription.visitDate}</span>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white mt-1">
              {prescription.doctorName}
            </h3>
            <p className="text-xs text-stone-300">
              {prescription.facilityName}
            </p>
          </div>

          {/* Audio Master Trigger */}
          <button
            onClick={handleSpeakFullOverview}
            className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all shrink-0 ${
              isSpeakingFull
                ? 'bg-amber-400 text-stone-900 ring-2 ring-amber-300 animate-pulse'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {isSpeakingFull ? (
              <>
                <VolumeX className="w-4 h-4" />
                <span>{t.stopAudio}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" />
                <span>{t.listenToAudio} (పూర్తి వివరణ)</span>
              </>
            )}
          </button>
        </div>

        {/* Diagnosis & Simple Translation Banner */}
        <div className="mt-4 pt-4 border-t border-stone-800 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="bg-stone-800/60 p-3 rounded-xl border border-stone-700/50">
            <span className="text-[11px] text-stone-400 uppercase tracking-wider block">
              Doctor Written Diagnosis:
            </span>
            <span className="font-semibold text-stone-100 text-sm mt-0.5 block">
              {prescription.diagnosis}
            </span>
          </div>

          <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-700/30">
            <span className="text-[11px] text-emerald-300 uppercase tracking-wider block font-semibold">
              గ్రామీణ రోగికి తేలికపాటి వివరణ (Vernacular):
            </span>
            <span className="font-medium text-emerald-100 text-sm mt-0.5 block font-indic">
              {prescription.diagnosisExplanation || prescription.diagnosis}
            </span>
          </div>
        </div>
      </div>

      {/* Main Medications List */}
      <div className="p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-stone-200 pb-3">
          <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <Pill className="w-4 h-4 text-emerald-600" />
            <span>{t.translationTitle}</span>
          </h4>
          <span className="text-xs text-stone-500">
            {prescription.medications.length} Medicines Prescribed
          </span>
        </div>

        <div className="space-y-4">
          {prescription.medications.map((med, idx) => {
            const isSpeakingThis = activeSpeakingMedId === med.id;

            return (
              <div
                key={med.id || idx}
                className="p-4 rounded-xl border border-stone-200 hover:border-emerald-300 bg-stone-50/50 hover:bg-white transition-all space-y-3"
              >
                {/* Medicine Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-bold text-stone-900">
                          {med.medicineName}
                        </span>
                        <span className="text-xs px-2 py-0.5 bg-stone-200 text-stone-800 rounded font-mono font-semibold">
                          {med.dosage}
                        </span>
                      </div>
                      <p className="text-xs text-stone-500 font-indic">
                        {med.purposeSimple}
                      </p>
                    </div>
                  </div>

                  {/* Individual Audio Readout Button */}
                  <button
                    onClick={() => handleSpeakMedication(med)}
                    className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors self-start sm:self-auto ${
                      isSpeakingThis
                        ? 'bg-amber-100 text-amber-900 border border-amber-300 animate-pulse'
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200'
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{isSpeakingThis ? t.stopAudio : t.listenToAudio}</span>
                  </button>
                </div>

                {/* Timing & Food Schedule Visualizer */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
                  <div className="p-2 bg-white rounded-lg border border-stone-200 flex items-center gap-2">
                    <span className="text-stone-400">Dose Code:</span>
                    <span className="font-mono font-bold text-emerald-800">
                      {med.frequencyCode}
                    </span>
                  </div>

                  <div className="p-2 bg-white rounded-lg border border-stone-200 flex items-center gap-2">
                    <span className="text-stone-400">Timing:</span>
                    <span className="font-semibold text-stone-800 capitalize">
                      {med.relationToFood === 'after_food'
                        ? 'భోజనం తర్వాత (After Food)'
                        : med.relationToFood === 'before_food'
                        ? 'భోజనానికి ముందు (Before Food)'
                        : 'నీటితో (With Water)'}
                    </span>
                  </div>

                  <div className="p-2 bg-white rounded-lg border border-stone-200 flex items-center gap-2">
                    <span className="text-stone-400">Duration:</span>
                    <span className="font-semibold text-stone-800">
                      {med.durationDays} Days (రోజులు)
                    </span>
                  </div>

                  {/* Visual Times of Day */}
                  <div className="p-2 bg-white rounded-lg border border-stone-200 flex items-center gap-1.5">
                    <span
                      className={`px-1.5 py-0.5 text-[10px] rounded font-semibold ${
                        med.scheduleTimes.morning
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-stone-100 text-stone-400 opacity-50'
                      }`}
                    >
                      ఉదయం
                    </span>
                    <span
                      className={`px-1.5 py-0.5 text-[10px] rounded font-semibold ${
                        med.scheduleTimes.afternoon
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-stone-100 text-stone-400 opacity-50'
                      }`}
                    >
                      మధ్యాహ్నం
                    </span>
                    <span
                      className={`px-1.5 py-0.5 text-[10px] rounded font-semibold ${
                        med.scheduleTimes.night
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-stone-100 text-stone-400 opacity-50'
                      }`}
                    >
                      రాత్రి
                    </span>
                  </div>
                </div>

                {/* Plain-Language Step-by-Step Translation Box */}
                <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3">
                  <span className="text-[11px] font-bold text-emerald-900 block mb-1">
                    {t.patientSimplified}:
                  </span>
                  <p className="text-sm font-semibold text-emerald-950 font-indic leading-relaxed">
                    {med.simplifiedExplanation}
                  </p>
                  {med.precautions && (
                    <div className="mt-2 pt-2 border-t border-emerald-200/50 flex items-start gap-1.5 text-xs text-emerald-900">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span>{med.precautions}</span>
                    </div>
                  )}
                </div>

                {/* Original Doctor Writing Preserved */}
                <div className="text-[11px] text-stone-500 font-mono flex items-center gap-2">
                  <span className="text-stone-400">Prescription Line:</span>
                  <span>"{med.doctorInstruction}"</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Medical Terms Glossary (Hypertension, Diabetes, etc.) */}
        {prescription.medicalTermsSimplified && prescription.medicalTermsSimplified.length > 0 && (
          <div className="mt-6 pt-4 border-t border-stone-200">
            <h5 className="text-xs font-bold text-stone-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-emerald-700" />
              <span>{t.medicalTermsHeader}</span>
            </h5>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {prescription.medicalTermsSimplified.map((item, i) => (
                <div
                  key={i}
                  className="p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs space-y-1"
                >
                  <span className="font-bold text-stone-900 block">{item.term}</span>
                  <span className="text-stone-600 font-indic block">{item.simpleMeaning}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Doctor Advice & Review Timeline */}
        <div className="p-4 bg-amber-50/60 border border-amber-200 rounded-xl text-xs text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <span className="font-bold block">
              డాక్టర్ ఇచ్చిన అదనపు జాగ్రత్తలు (Doctor Advice):
            </span>
            <p className="text-stone-700">{prescription.doctorAdvice}</p>
          </div>
          <div className="px-3 py-1.5 bg-amber-200/70 rounded-lg font-semibold whitespace-nowrap text-amber-950 shrink-0">
            {t.reviewDoctorDays}: {prescription.reviewDays} Days
          </div>
        </div>

        {/* Add to Reminders CTA */}
        {onAddToReminders && (
          <div className="pt-2">
            <button
              onClick={handleAddRemindersClick}
              disabled={remindersAdded}
              className="w-full py-3 px-4 bg-emerald-700 hover:bg-emerald-800 active:scale-[0.99] text-white rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-xs disabled:bg-emerald-900"
            >
              {remindersAdded ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>రిమైండర్లు విజయవంతంగా షెడ్యూల్ చేయబడ్డాయి (Reminders Added)</span>
                </>
              ) : (
                <>
                  <Calendar className="w-4 h-4" />
                  <span>ఈ ప్రిస్క్రిప్షన్‌ను నేటి మందుల రిమైండర్‌లలో చేర్చండి (+ Schedule Reminders)</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
