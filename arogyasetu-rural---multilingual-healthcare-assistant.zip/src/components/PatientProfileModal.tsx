import React, { useState } from 'react';
import { X, UserPlus, Check, User, Phone, MapPin, Calendar, Heart } from 'lucide-react';
import { Patient, SupportedLanguage, LANGUAGES } from '../types';
import { TRANSLATIONS } from '../translations';

interface PatientProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  patients: Patient[];
  activePatient: Patient | null;
  onSelectPatient: (patient: Patient) => void;
  onRegisterPatient: (patientData: any) => Promise<void>;
  currentLanguage: SupportedLanguage;
}

export const PatientProfileModal: React.FC<PatientProfileModalProps> = ({
  isOpen,
  onClose,
  patients,
  activePatient,
  onSelectPatient,
  onRegisterPatient,
  currentLanguage,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const [isRegisteringNew, setIsRegisteringNew] = useState(false);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [age, setAge] = useState('45');
  const [gender, setGender] = useState('Female');
  const [village, setVillage] = useState('Narsampet');
  const [district, setDistrict] = useState('Warangal, Telangana');
  const [preferredLang, setPreferredLang] = useState<SupportedLanguage>(currentLanguage);
  const [conditions, setConditions] = useState('Diabetes, BP checkup');
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmitNew = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !mobile) return;
    setSubmitting(true);
    try {
      await onRegisterPatient({
        name,
        mobile,
        age: parseInt(age) || 40,
        gender,
        village,
        district,
        preferredLanguage: preferredLang,
        chronicConditions: conditions.split(',').map((c) => c.trim()).filter(Boolean),
      });
      setIsRegisteringNew(false);
      setName('');
      setMobile('');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <User className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-base text-stone-900">
              {isRegisteringNew ? t.newPatientRegistration : t.patientProfileTitle}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5">
          {!isRegisteringNew ? (
            <div className="space-y-4">
              {/* Active Profile Card */}
              {activePatient && (
                <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-emerald-950 text-lg">
                          {activePatient.name}
                        </h4>
                        <span className="text-xs px-2 py-0.5 bg-emerald-200/80 text-emerald-900 rounded-md font-semibold">
                          Active Patient
                        </span>
                      </div>
                      <p className="text-xs font-mono text-emerald-800 mt-0.5">
                        {t.healthIdBadge}: {activePatient.healthId}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-emerald-200/60 text-xs text-stone-700">
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{activePatient.mobile}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{activePatient.age} yrs · {activePatient.gender}</span>
                    </div>
                    <div className="flex items-center gap-1.5 col-span-2">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{activePatient.village}, {activePatient.district}</span>
                    </div>
                    <div className="flex items-center gap-1.5 col-span-2">
                      <Heart className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Conditions: {activePatient.chronicConditions.join(', ')}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Patient Switcher List */}
              <div>
                <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2">
                  {t.switchPatient} ({patients.length})
                </p>
                <div className="space-y-2">
                  {patients.map((pat) => (
                    <button
                      key={pat.id}
                      onClick={() => onSelectPatient(pat)}
                      className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                        activePatient?.id === pat.id
                          ? 'border-emerald-600 bg-emerald-50/40 font-semibold'
                          : 'border-stone-200 hover:border-emerald-300 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-stone-200 text-stone-700 font-bold flex items-center justify-center text-sm">
                          {pat.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm text-stone-900 font-medium">
                            {pat.name} ({pat.age}y)
                          </p>
                          <p className="text-xs text-stone-500">
                            {pat.village} · {pat.mobile}
                          </p>
                        </div>
                      </div>
                      {activePatient?.id === pat.id && (
                        <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                          <Check className="w-4 h-4" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Register New CTA */}
              <button
                onClick={() => setIsRegisteringNew(true)}
                className="w-full py-2.5 px-4 border border-dashed border-emerald-500 hover:bg-emerald-50/60 rounded-xl text-emerald-800 text-xs font-semibold flex items-center justify-center gap-2 transition-colors mt-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>+ {t.newPatientRegistration}</span>
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmitNew} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Full Name (రోగి పేరు) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Venkataramana Reddy"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Mobile Number (ఫోన్) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="98480xxxxx"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Age (వయస్సు)
                  </label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Gender
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                  >
                    <option value="Female">Female (మహిళ)</option>
                    <option value="Male">Male (పురుషుడు)</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Language (భాష)
                  </label>
                  <select
                    value={preferredLang}
                    onChange={(e) => setPreferredLang(e.target.value as SupportedLanguage)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                  >
                    {LANGUAGES.map((l) => (
                      <option key={l.code} value={l.code}>
                        {l.nativeName} ({l.name})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Village (గ్రామం)
                  </label>
                  <input
                    type="text"
                    value={village}
                    onChange={(e) => setVillage(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    District & State
                  </label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Health Complaints / Chronic Conditions
                </label>
                <input
                  type="text"
                  placeholder="e.g. High BP, Joint Pain, Fever"
                  value={conditions}
                  onChange={(e) => setConditions(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsRegisteringNew(false)}
                  className="flex-1 py-2 text-xs font-semibold text-stone-600 bg-stone-100 rounded-lg hover:bg-stone-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 py-2 text-xs font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors disabled:opacity-50"
                >
                  {submitting ? 'Saving...' : t.saveProfile}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
