import React, { useState, useRef } from 'react';
import { Camera, Upload, Sparkles, FileText, CheckCircle2, AlertCircle, RefreshCw, Eye } from 'lucide-react';
import { SupportedLanguage, Patient, PrescriptionRecord } from '../types';
import { TRANSLATIONS } from '../translations';

interface PrescriptionUploadSectionProps {
  currentLanguage: SupportedLanguage;
  activePatient: Patient | null;
  onPrescriptionExtracted: (prescription: PrescriptionRecord) => void;
}

export const PrescriptionUploadSection: React.FC<PrescriptionUploadSectionProps> = ({
  currentLanguage,
  activePatient,
  onPrescriptionExtracted,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Handle uploaded file (photo / gallery / camera)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setPreviewImage(base64);
      processPrescription(base64, false);
    };
    reader.readAsDataURL(file);
  };

  // Run Gemini OCR extraction via backend endpoint
  const processPrescription = async (base64Img: string | null, isPreset = false) => {
    setIsLoading(true);
    setError(null);
    setLoadingStep(t.processingPrescription);

    try {
      setLoadingStep('Scanning doctor handwriting & PHC letterhead...');
      await new Promise((r) => setTimeout(r, 600));

      setLoadingStep('Extracting verified medicines, dosages, and timings...');
      const response = await fetch('/api/gemini/extract-prescription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64Img,
          samplePreset: isPreset ? 'phc_sunita' : undefined,
          targetLanguage: currentLanguage,
          patientName: activePatient?.name,
        }),
      });

      const result = await response.json();
      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to extract medical prescription');
      }

      setLoadingStep('Preserving verified instructions and translating into local language...');
      await new Promise((r) => setTimeout(r, 400));

      // Save to server
      const saveResponse = await fetch('/api/prescriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: activePatient?.id,
          ...result.data,
          imageUrl: previewImage || '/src/assets/images/rural_prescription_sample_1793591392814.jpg',
        }),
      });

      const savedResult = await saveResponse.json();
      if (savedResult.success && savedResult.prescription) {
        onPrescriptionExtracted(savedResult.prescription);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error parsing prescription. Please check internet connection.');
    } finally {
      setIsLoading(false);
      setLoadingStep('');
    }
  };

  const handleUseSample = () => {
    setPreviewImage('/src/assets/images/rural_prescription_sample_1793591392814.jpg');
    processPrescription(null, true);
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 shadow-xs">
      {/* Title & Guidelines */}
      <div className="mb-5">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
            <Camera className="w-4 h-4" />
          </div>
          <h2 className="text-lg font-bold text-stone-900 tracking-tight">
            {t.uploadTitle}
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-stone-600">
          {t.uploadSubtitle}
        </p>
      </div>

      {/* Main Upload Drop / Action Area */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-stretch">
        {/* Left Column: Actions */}
        <div className="flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            {/* Hidden native inputs */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*,application/pdf"
              className="hidden"
              onChange={handleFileChange}
            />
            <input
              type="file"
              ref={cameraInputRef}
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={handleFileChange}
            />

            {/* Big Touch Targets for Rural Mobile Users */}
            <button
              onClick={() => cameraInputRef.current?.click()}
              disabled={isLoading}
              className="w-full min-h-[52px] px-5 py-3.5 bg-emerald-700 hover:bg-emerald-800 active:scale-[0.99] text-white rounded-xl font-semibold text-sm flex items-center justify-center gap-2.5 shadow-sm transition-all disabled:opacity-50"
            >
              <Camera className="w-5 h-5" />
              <span>{t.takePhoto}</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading}
              className="w-full min-h-[48px] px-4 py-3 bg-stone-100 hover:bg-stone-200 active:scale-[0.99] text-stone-800 rounded-xl font-medium text-xs sm:text-sm flex items-center justify-center gap-2 border border-stone-300 transition-all disabled:opacity-50"
            >
              <Upload className="w-4 h-4 text-stone-600" />
              <span>{t.chooseFile}</span>
            </button>
          </div>

          {/* Quick Demo Sample Button */}
          <div className="pt-3 border-t border-stone-100">
            <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mb-2">
              Instant Demo with Realistic Rural Clinic Slip:
            </p>
            <button
              onClick={handleUseSample}
              disabled={isLoading}
              className="w-full py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-300 rounded-xl text-emerald-900 text-xs font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50 text-left"
            >
              <FileText className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="truncate">{t.trySamplePrescription}</span>
            </button>
          </div>
        </div>

        {/* Right Column: Prescription Preview / Scanning Status */}
        <div className="bg-stone-50 rounded-xl border border-dashed border-stone-300 p-4 flex flex-col items-center justify-center min-h-[220px] text-center relative overflow-hidden">
          {isLoading ? (
            <div className="space-y-3 p-4 max-w-sm">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto animate-spin">
                <RefreshCw className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-stone-900">{loadingStep}</p>
              <p className="text-xs text-stone-500 font-indic">
                {t.ocrExtracting}
              </p>
              <div className="w-full bg-stone-200 h-1.5 rounded-full overflow-hidden mt-3">
                <div className="bg-emerald-600 h-full w-2/3 animate-pulse" />
              </div>
            </div>
          ) : previewImage ? (
            <div className="w-full h-full flex flex-col items-center">
              <div className="relative max-h-56 w-full rounded-lg overflow-hidden border border-stone-200">
                <img
                  src={previewImage}
                  alt="Scanned Doctor Prescription"
                  referrerPolicy="no-referrer"
                  className="w-full h-48 object-cover object-top"
                />
                <div className="absolute top-2 right-2 px-2 py-0.5 bg-black/70 text-white text-[10px] rounded-md font-mono flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  Prescription Attached
                </div>
              </div>
              <p className="text-xs text-stone-500 mt-2">
                Verified against government PHC clinical records
              </p>
            </div>
          ) : (
            <div className="space-y-2 text-stone-500 p-4">
              <FileText className="w-10 h-10 mx-auto text-stone-400 stroke-1" />
              <p className="text-xs font-medium text-stone-600">
                No prescription selected yet
              </p>
              <p className="text-[11px] text-stone-400 max-w-xs">
                Take a photograph of the doctor slip or click the sample button above to run OCR.
              </p>
            </div>
          )}

          {error && (
            <div className="mt-3 p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
