import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, ShieldAlert, Sparkles, AlertCircle, X, HelpCircle, PhoneCall, RefreshCw } from 'lucide-react';
import { SupportedLanguage, Patient, PrescriptionRecord } from '../types';
import { TRANSLATIONS } from '../translations';
import { speechManager, createSpeechRecognizer } from '../utils/audio';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: SupportedLanguage;
  activePatient: Patient | null;
  activePrescription: PrescriptionRecord | null;
  onOpenEmergency: () => void;
}

interface MessageItem {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  englishSummary?: string;
  isEmergency?: boolean;
  emergencyAction?: string;
  timestamp: string;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  currentLanguage,
  activePatient,
  activePrescription,
  onOpenEmergency,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const [isListening, setIsListening] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isSpeakingAnswer, setIsSpeakingAnswer] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  const [messages, setMessages] = useState<MessageItem[]>([
    {
      id: 'm-init',
      sender: 'assistant',
      text:
        currentLanguage === 'te'
          ? 'నమస్కారం! నేను మీ ఆరోగ్య సహాయకుడిని. మీ మందులు లేదా జాగ్రత్తల గురించి మైక్ నొక్కి మాట్లాడండి.'
          : currentLanguage === 'hi'
          ? 'नमस्ते! मैं आपका स्वास्थ्य सहायक हूँ। अपनी दवाई या सेहत के बारे में बोलकर पूछें।'
          : currentLanguage === 'ta'
          ? 'வணக்கம்! உங்கள் மருந்துகள் பற்றி மைக் அழுத்தி தமிழில் பேசுங்கள்.'
          : 'Hello! I am your rural healthcare voice assistant. Tap the microphone and ask any question in your language.',
      timestamp: 'Just now',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  // Initialize Speech Recognition
  const startListening = () => {
    speechManager.stop();
    setIsSpeakingAnswer(false);

    const recognizer = createSpeechRecognizer(
      currentLanguage,
      (transcript) => {
        setIsListening(false);
        setInputText(transcript);
        handleSendQuery(transcript);
      },
      (err) => {
        console.warn('Speech recognition error:', err);
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      }
    );

    if (!recognizer) {
      setSpeechSupported(false);
      // Fallback: prompt user to type or use sample questions
      return;
    }

    try {
      recognizer.start();
      recognitionRef.current = recognizer;
      setIsListening(true);
    } catch {
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
    }
    setIsListening(false);
  };

  // Submit query to Gemini 3.8 Flash backend
  const handleSendQuery = async (queryToSend?: string) => {
    const text = queryToSend || inputText;
    if (!text.trim()) return;

    const userMsg: MessageItem = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/voice-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          queryText: text.trim(),
          targetLanguage: currentLanguage,
          patientContext: {
            name: activePatient?.name,
            age: activePatient?.age,
            village: activePatient?.village,
            prescription: activePrescription
              ? {
                  diagnosis: activePrescription.diagnosis,
                  doctorName: activePrescription.doctorName,
                  medications: activePrescription.medications.map((m) => ({
                    name: m.medicineName,
                    dosage: m.dosage,
                    timing: m.relationToFood,
                    instruction: m.doctorInstruction,
                  })),
                }
              : null,
          },
        }),
      });

      const resData = await response.json();
      if (!resData.success || !resData.data) {
        throw new Error(resData.error || 'Failed to process voice query');
      }

      const assistantReply = resData.data;
      const botMsg: MessageItem = {
        id: `msg-bot-${Date.now()}`,
        sender: 'assistant',
        text: assistantReply.spokenResponse,
        englishSummary: assistantReply.englishSummary,
        isEmergency: assistantReply.isEmergency,
        emergencyAction: assistantReply.emergencyAction,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);

      // Automatically read response aloud in patient's language
      setIsSpeakingAnswer(true);
      speechManager.speak(
        assistantReply.spokenResponse,
        currentLanguage,
        () => setIsSpeakingAnswer(true),
        () => setIsSpeakingAnswer(false)
      );

      // If urgent red flag emergency detected, play alert chime
      if (assistantReply.isEmergency) {
        speechManager.playChime(false);
      }
    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          sender: 'assistant',
          text: 'క్షమించండి, సర్వర్‌లో సమస్య వచ్చింది. దయచేసి మళ్ళీ అడగండి లేదా 104 హెల్ప్‌లైన్‌కు కాల్ చేయండి.',
          timestamp: 'Just now',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStopSpeaking = () => {
    speechManager.stop();
    setIsSpeakingAnswer(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-xl w-full h-[88vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 flex items-center justify-center text-white">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base leading-tight text-white">
                {t.voiceTitle}
              </h3>
              <p className="text-[11px] text-stone-300">
                {activePatient?.name ? `Patient: ${activePatient.name} · ` : ''}
                Real-time regional speech & audio playback
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isSpeakingAnswer && (
              <button
                onClick={handleStopSpeaking}
                className="px-2 py-1 bg-amber-400 text-stone-900 rounded-md text-[11px] font-bold flex items-center gap-1 animate-pulse"
              >
                <VolumeX className="w-3.5 h-3.5" />
                <span>Stop</span>
              </button>
            )}
            <button
              onClick={() => {
                speechManager.stop();
                onClose();
              }}
              className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Safety Disclaimer Banner */}
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-[11px] text-amber-900 flex items-center gap-2">
          <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
          <span>{t.safetyDisclaimer}</span>
        </div>

        {/* Chat / Speech Transcript Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 bg-stone-50/70">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.sender === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[88%] p-3.5 rounded-2xl text-xs sm:text-sm font-indic leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-emerald-700 text-white rounded-br-xs'
                    : msg.isEmergency
                    ? 'bg-rose-50 text-rose-950 border-2 border-rose-400 rounded-bl-xs'
                    : 'bg-white text-stone-900 border border-stone-200 shadow-2xs rounded-bl-xs'
                }`}
              >
                {msg.isEmergency && (
                  <div className="mb-2 p-2 bg-rose-600 text-white rounded-lg flex items-center justify-between">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4" />
                      అత్యవసర హెచ్చరిక (EMERGENCY)
                    </span>
                    <button
                      onClick={onOpenEmergency}
                      className="px-2 py-1 bg-white text-rose-700 font-bold text-[11px] rounded hover:bg-rose-100 flex items-center gap-1"
                    >
                      <PhoneCall className="w-3 h-3" />
                      108 కాల్
                    </button>
                  </div>
                )}

                <p className="font-medium">{msg.text}</p>

                {msg.englishSummary && (
                  <p className="mt-2 pt-2 border-t border-stone-200/60 text-[11px] text-stone-500 font-sans">
                    Doctor Summary: {msg.englishSummary}
                  </p>
                )}

                <div className="flex items-center justify-between mt-1 pt-1 text-[10px] text-stone-400">
                  <span>{msg.timestamp}</span>
                  {msg.sender === 'assistant' && (
                    <button
                      onClick={() => speechManager.speak(msg.text, currentLanguage)}
                      className="text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1 ml-2"
                    >
                      <Volume2 className="w-3 h-3" /> Listen
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 p-3 bg-white rounded-2xl border border-stone-200 w-fit">
              <RefreshCw className="w-4 h-4 text-emerald-600 animate-spin" />
              <span className="text-xs text-stone-500 font-indic">
                AI అర్థం చేసుకుంటోంది & సమాధానం సిద్ధం చేస్తోంది...
              </span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Question Chips for Rural Villagers */}
        <div className="p-3 bg-white border-t border-stone-200">
          <p className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider mb-2">
            సాధారణ ప్రశ్నలు (Quick Questions):
          </p>
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {t.sampleQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSendQuery(q)}
                disabled={isLoading || isListening}
                className="px-3 py-1.5 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-900 border border-stone-200 rounded-lg text-xs whitespace-nowrap text-stone-700 font-indic transition-colors shrink-0 disabled:opacity-50"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Voice Input & Mic Bottom Bar */}
        <div className="p-4 bg-stone-100 border-t border-stone-200 flex flex-col items-center gap-3">
          {/* Main Huge Thumb Mic Target */}
          <div className="relative flex items-center justify-center">
            {isListening && (
              <div className="absolute w-20 h-20 rounded-full bg-emerald-400/30 animate-ping pointer-events-none" />
            )}
            <button
              onClick={isListening ? stopListening : startListening}
              className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 ${
                isListening
                  ? 'bg-rose-600 text-white ring-4 ring-rose-200'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
              title={isListening ? 'Stop' : 'Speak'}
            >
              {isListening ? (
                <MicOff className="w-7 h-7" />
              ) : (
                <Mic className="w-7 h-7" />
              )}
            </button>
          </div>

          <p className="text-xs font-semibold text-stone-700 text-center">
            {isListening ? (
              <span className="text-rose-600 animate-pulse font-bold">
                {t.listeningNow} (మాట్లాడండి...)
              </span>
            ) : (
              <span>{t.tapToSpeak}</span>
            )}
          </p>

          {/* Typing fallback input for non-voice setups */}
          <div className="w-full flex gap-2">
            <input
              type="text"
              placeholder={t.askDoctorQuestion}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendQuery()}
              className="flex-1 px-3 py-2 text-xs sm:text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
            <button
              onClick={() => handleSendQuery()}
              disabled={!inputText.trim() || isLoading}
              className="px-4 py-2 bg-stone-900 text-white rounded-xl text-xs font-bold hover:bg-stone-800 disabled:opacity-40 transition-colors shrink-0"
            >
              అడగండి (Ask)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
