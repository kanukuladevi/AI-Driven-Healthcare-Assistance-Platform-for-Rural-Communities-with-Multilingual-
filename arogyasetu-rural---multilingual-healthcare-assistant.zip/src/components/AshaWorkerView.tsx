import React, { useState } from 'react';
import { HeartHandshake, Users, ClipboardCheck, AlertCircle, Phone, Calendar, Search, Check, Plus, MessageSquare } from 'lucide-react';
import { Patient, PrescriptionRecord, MedicationReminder, AshaWorker, SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../translations';

interface AshaWorkerViewProps {
  patients: Patient[];
  prescriptions: PrescriptionRecord[];
  reminders: MedicationReminder[];
  ashaWorkers: AshaWorker[];
  currentLanguage: SupportedLanguage;
  onOpenPatientModal: () => void;
  onSelectPatient: (pat: Patient) => void;
  onUpdateNotes: (prescriptionId: string, notes: string, verified: boolean) => Promise<void>;
}

export const AshaWorkerView: React.FC<AshaWorkerViewProps> = ({
  patients,
  prescriptions,
  reminders,
  ashaWorkers,
  currentLanguage,
  onOpenPatientModal,
  onSelectPatient,
  onUpdateNotes,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRx, setSelectedRx] = useState<PrescriptionRecord | null>(prescriptions[0] || null);
  const [noteText, setNoteText] = useState(selectedRx?.ashaNotes || '');
  const [isSavingNote, setIsSavingNote] = useState(false);
  const [filterRisk, setFilterRisk] = useState<'All' | 'HighRisk'>('All');

  const currentAsha = ashaWorkers[0];

  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.village.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.mobile.includes(searchQuery);

    if (filterRisk === 'HighRisk') {
      return matchesSearch && p.chronicConditions.length > 1;
    }
    return matchesSearch;
  });

  const handleSaveNotes = async () => {
    if (!selectedRx) return;
    setIsSavingNote(true);
    try {
      await onUpdateNotes(selectedRx.id, noteText, true);
    } finally {
      setIsSavingNote(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* ASHA Profile Card & Cluster Banner */}
      <div className="bg-emerald-900 text-white rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center font-bold text-white text-lg">
              <HeartHandshake className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">
                  {currentAsha ? currentAsha.name : 'Sunita Bai'}
                </h2>
                <span className="text-xs px-2 py-0.5 bg-emerald-700 text-emerald-100 rounded-md font-medium">
                  {currentAsha ? currentAsha.role : 'ASHA Worker'}
                </span>
              </div>
              <p className="text-xs text-emerald-200 mt-0.5">
                Assigned: {currentAsha ? currentAsha.assignedVillage : 'Narsampet Rural Cluster'} · Phone: {currentAsha?.phone}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenPatientModal}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Register New Villager</span>
            </button>
          </div>
        </div>

        {/* Quick Cluster Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-emerald-800/80 text-xs">
          <div className="bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-800/50">
            <span className="text-emerald-300 block">Registered Patients</span>
            <span className="text-lg font-bold font-mono text-white">
              {patients.length}
            </span>
          </div>
          <div className="bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-800/50">
            <span className="text-emerald-300 block">Active Prescriptions</span>
            <span className="text-lg font-bold font-mono text-white">
              {prescriptions.length}
            </span>
          </div>
          <div className="bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-800/50">
            <span className="text-emerald-300 block">High Risk Elders</span>
            <span className="text-lg font-bold font-mono text-amber-300">
              {patients.filter((p) => p.chronicConditions.length > 1).length}
            </span>
          </div>
          <div className="bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-800/50">
            <span className="text-emerald-300 block">Pending Home Visits</span>
            <span className="text-lg font-bold font-mono text-white">
              {currentAsha?.pendingHomeVisits || 3}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Patients List + Prescription Review */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Villagers Roster */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-stone-200 p-4 sm:p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-700" />
              <span>Village Patient Roster</span>
            </h3>

            <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-lg text-xs">
              <button
                onClick={() => setFilterRisk('All')}
                className={`px-2 py-0.5 rounded font-medium ${
                  filterRisk === 'All' ? 'bg-white shadow-xs text-stone-900' : 'text-stone-500'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterRisk('HighRisk')}
                className={`px-2 py-0.5 rounded font-medium ${
                  filterRisk === 'HighRisk' ? 'bg-white shadow-xs text-amber-900' : 'text-stone-500'
                }`}
              >
                High Risk
              </button>
            </div>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by name, village, or phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          {/* Patient Cards */}
          <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
            {filteredPatients.map((pat) => {
              const patRx = prescriptions.find((rx) => rx.patientId === pat.id);
              const patReminders = reminders.filter((r) => r.patientId === pat.id);
              const patTaken = patReminders.filter((r) => r.takenToday).length;
              const adherencePct =
                patReminders.length > 0 ? Math.round((patTaken / patReminders.length) * 100) : 100;

              return (
                <div
                  key={pat.id}
                  onClick={() => {
                    onSelectPatient(pat);
                    if (patRx) setSelectedRx(patRx);
                  }}
                  className="p-3 rounded-xl border border-stone-200 hover:border-emerald-300 bg-stone-50/50 hover:bg-white transition-all cursor-pointer space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
                        {pat.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-stone-900">
                          {pat.name}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {pat.age}y · {pat.village}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono">
                        {adherencePct}% Adherence
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-stone-600 pt-1 border-t border-stone-100">
                    <span className="truncate max-w-[180px]">
                      {pat.chronicConditions.join(', ')}
                    </span>
                    <a
                      href={`tel:${pat.mobile}`}
                      onClick={(e) => e.stopPropagation()}
                      className="text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" />
                      <span>Call</span>
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Prescription Review & ASHA Field Notes */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-200 pb-3">
            <div>
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <ClipboardCheck className="w-4 h-4 text-emerald-700" />
                <span>ASHA Verification & Clinical Notes</span>
              </h3>
              <p className="text-xs text-stone-500">
                Review verified medicine translations and log home-visit follow-ups.
              </p>
            </div>
            {selectedRx?.verifiedByAsha && (
              <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 font-semibold rounded-md flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                Verified
              </span>
            )}
          </div>

          {selectedRx ? (
            <div className="space-y-4">
              {/* Doctor Header */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-1">
                <div className="flex justify-between font-bold text-stone-900">
                  <span>{selectedRx.doctorName}</span>
                  <span>{selectedRx.visitDate}</span>
                </div>
                <p className="text-stone-600">{selectedRx.facilityName}</p>
                <p className="font-semibold text-emerald-900 mt-1">
                  Diagnosis: {selectedRx.diagnosis}
                </p>
              </div>

              {/* Medicines Summary */}
              <div className="space-y-2">
                <p className="text-xs font-semibold text-stone-600 uppercase tracking-wider">
                  Verified Medication Translation (Telugu):
                </p>
                {selectedRx.medications.map((m, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg border border-stone-200 bg-white text-xs space-y-1"
                  >
                    <div className="flex justify-between font-bold text-stone-800">
                      <span>{m.medicineName} ({m.dosage})</span>
                      <span className="font-mono text-emerald-700">{m.frequencyCode}</span>
                    </div>
                    <p className="text-stone-600 font-indic">
                      {m.simplifiedExplanation}
                    </p>
                  </div>
                ))}
              </div>

              {/* ASHA Field Notes Area */}
              <div className="pt-2 border-t border-stone-200 space-y-2">
                <label className="block text-xs font-bold text-stone-800 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-700" />
                  <span>ASHA Home Visit Follow-Up Notes:</span>
                </label>
                <textarea
                  rows={3}
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  placeholder="e.g. Visited patient home on Monday. BP measured 130/85. Patient understands to take Paracetamol after food. Family reminded about ORS."
                  className="w-full p-2.5 text-xs border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
                <button
                  onClick={handleSaveNotes}
                  disabled={isSavingNote}
                  className="py-2 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{isSavingNote ? 'Saving...' : 'Save ASHA Verification'}</span>
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-stone-500 text-center py-8">
              Select a patient on the left to review their medical records and attach notes.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
