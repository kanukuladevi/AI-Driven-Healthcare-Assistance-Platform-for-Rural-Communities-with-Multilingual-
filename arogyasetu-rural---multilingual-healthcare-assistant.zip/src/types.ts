export type SupportedLanguage = 'te' | 'hi' | 'ta' | 'kn' | 'bn' | 'en';

export interface LanguageMeta {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
  ttsVoiceCode: string;
}

export const LANGUAGES: LanguageMeta[] = [
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳', ttsVoiceCode: 'te-IN' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳', ttsVoiceCode: 'hi-IN' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳', ttsVoiceCode: 'ta-IN' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', flag: '🇮🇳', ttsVoiceCode: 'kn-IN' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', flag: '🇮🇳', ttsVoiceCode: 'bn-IN' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🌐', ttsVoiceCode: 'en-IN' },
];

export interface Patient {
  id: string;
  name: string;
  mobile: string;
  age: number;
  gender: string;
  village: string;
  district: string;
  preferredLanguage: SupportedLanguage;
  healthId: string;
  chronicConditions: string[];
  registeredDate: string;
}

export interface MedicationItem {
  id: string;
  medicineName: string;
  form: string;
  dosage: string;
  frequencyCode: string;
  scheduleTimes: {
    morning: boolean;
    afternoon: boolean;
    night: boolean;
  };
  relationToFood: 'after_food' | 'before_food' | 'with_water';
  durationDays: number;
  doctorInstruction: string;
  simplifiedExplanation: string;
  precautions: string;
  purposeSimple: string;
}

export interface PrescriptionRecord {
  id: string;
  patientId: string;
  doctorName: string;
  facilityName: string;
  visitDate: string;
  diagnosis: string;
  diagnosisExplanation: string;
  doctorAdvice: string;
  reviewDays: number;
  medications: MedicationItem[];
  medicalTermsSimplified: { term: string; simpleMeaning: string }[];
  uploadedAt: string;
  imageUrl?: string;
  verifiedByAsha: boolean;
  ashaNotes?: string;
}

export interface MedicationReminder {
  id: string;
  patientId: string;
  prescriptionId: string;
  medicineName: string;
  dosage: string;
  timeSlot: 'Morning' | 'Afternoon' | 'Night';
  scheduledTime: string;
  relationToFood: string;
  takenToday: boolean;
  takenAt?: string;
}

export interface AshaWorker {
  id: string;
  name: string;
  role: string;
  phone: string;
  assignedVillage: string;
  assignedPatientsCount: number;
  pendingHomeVisits: number;
}

export interface VillageBulletin {
  id: string;
  title: string;
  date: string;
  description: string;
  category: string;
}

export interface AppData {
  patients: Patient[];
  prescriptions: PrescriptionRecord[];
  reminders: MedicationReminder[];
  ashaWorkers: AshaWorker[];
  villageBulletins: VillageBulletin[];
  analytics: {
    totalPatients: number;
    totalPrescriptions: number;
    totalReminders: number;
    adherenceRate: number;
    languageStats: Record<string, number>;
    activeAshaWorkers: number;
    highRiskFollowUps: number;
  };
}
